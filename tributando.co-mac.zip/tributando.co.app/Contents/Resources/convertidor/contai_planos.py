"""
Generador de Planos para Contai-Ilimitada desde el reporte DIAN.

Toma el mismo archivo DIAN que usa el convertidor Siigo y genera el plano de
ventas, compras y notas crédito de compras en formato Contai-Ilimitada
(contabilidad de partida doble por documento).

Nota: el reporte DIAN solo trae el IVA total y el total por documento, por lo
que todo se contabiliza al 19% (no se separa 19%/5%) y no se incluyen
retenciones en la fuente. Si un documento no trae IVA, se omite la línea de IVA.

Gastos/servicios: cada proveedor usa una cuenta contable distinta (arriendo,
honorarios, servicios públicos, etc.). La clasificación compra-vs-gasto y la
cuenta específica por NIT ya NO están hardcodeadas aquí: se resuelven por
empresa (identificada por su NIT) usando classifiers/ — reglas
(reglas_empresas/<nit_empresa>.json), caché de clasificaciones previas, e IA
como fallback para NITs nuevos. Ver [[project-multi-empresa]] en memoria:
cada empresa tiene su propio archivo de reglas, no se reusan cuentas de otra.
"""

import io
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

from converter import _leer_todo, _fecha
from classifiers import clasificar_lote_documentos
from classifiers.reglas import cargar_reglas


# Las cuentas contables (ventas, compras, gastos) y los números de comprobante
# son POR EMPRESA: viven en reglas_empresas/<nit_empresa>.json. Ver
# [[project-comprobantes-inverplas]] y [[project-multi-empresa]] en memoria.
# COMPROBANTES_DEFAULT aplica cuando la empresa no trae su propio listado
# (coincide con los códigos de INVERPLAS/ALEX NOREÑA salvo 'gasto', que varía).
COMPROBANTES_DEFAULT = {
    'venta': 4,        # 00004 VENTAS
    'nc_venta': 16,    # 00016 NOTA CREDITO VENTAS
    'compra': 3,       # 00003 COMPRAS
    'nc_compra': 15,   # 00015 NOTA CREDITO COMPRAS
    'gasto': 12,       # 00012 EGRESOS GASTOS (INVERPLAS; ALEX NOREÑA usa 2)
}

TIPO_DEBITO  = 1
TIPO_CREDITO = 2

# Las 13 columnas que Contai lee POR POSICIÓN. NO lleva el nombre del tercero:
# metérselo corría todo desde la séptima (el detalle quedaba con el nombre, el
# «Tipo» con la primera letra del detalle y el valor en la base) — así salió el
# reporte de inconsistencias de MULTIABARROTES.
HEADERS_CONTAI = [
    'Cuenta', 'Comprobante', 'Fecha(mm/dd/yyyy)', 'Comprobante', 'Documento Ref.',
    'Nit', 'Detalle', 'Tipo', 'VALORES', 'BASE', 'Centro de Costo',
    'Trans. Ext', 'Plazo'
]

_HEADER_FILL = PatternFill(fill_type='solid', fgColor='1a3a5c')
_HEADER_FONT = Font(bold=True, color='FFFFFF', name='Calibri', size=10)
_THIN_BORDER = Border(
    left=Side(style='thin', color='BFCCD8'),
    right=Side(style='thin', color='BFCCD8'),
    top=Side(style='thin', color='BFCCD8'),
    bottom=Side(style='thin', color='BFCCD8')
)


def _fmt_fecha(val):
    """La fecha como la recibe Contai: dd/mm/aaaa con BARRAS. Con guiones la
    rechazaba («La fecha NO es Válida») y el movimiento entraba sin fecha."""
    f = _fecha(val)
    try:
        return f.strftime('%d/%m/%Y')
    except AttributeError:
        return str(val) if val is not None else ''


def _fila_contai(cuenta, comp, fecha, folio, nit, detalle, tipo, valores, base=None,
                 nombre=''):
    """Una fila del plano Contai: 13 columnas, en el orden que él lee por posición.
    `nombre` se recibe pero NO se escribe: Contai no tiene esa columna."""
    return [
        cuenta, comp, fecha, folio, folio,
        str(nit) if nit else None, detalle, tipo, round(valores, 2),
        round(base, 2) if base is not None else None,
        None, None, None
    ]


def _escribir_headers(ws):
    for col, header in enumerate(HEADERS_CONTAI, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = _THIN_BORDER
    ws.row_dimensions[1].height = 20


def _escribir_fila(ws, row_idx, fila):
    for col, val in enumerate(fila, 1):
        cell = ws.cell(row=row_idx, column=col, value=val)
        cell.border = _THIN_BORDER
        # Formato numérico para VALORES (col 9) y BASE (col 10)
        if col in (9, 10) and isinstance(val, (int, float)):
            cell.number_format = '#,##0.00'


def _clasificar_tarifa_venta(base, iva):
    """
    Tarifa efectiva de la factura (iva/base): el reporte DIAN trae base e
    IVA por documento (no por línea/producto), así que documentos que
    mezclan 19% y 5% se aproximan a la tarifa dominante. Retorna '0', '5'
    o '19' (sufijo de las claves cuenta_ingreso_*/cuenta_iva_generado_*/
    cuenta_dev_ventas_* del JSON de la empresa). Solo es '0' cuando el IVA
    es realmente ~0 — si hay IVA se escribe siempre, aunque la tarifa no
    sea exacta, para no descuadrar el plano.
    """
    if abs(iva) < 0.01:
        return '0'
    rate = iva / base if abs(base) > 0.01 else 1.0
    if rate < 0.12:
        return '5'
    return '19'


# ========================================
# Retención en la fuente (config por empresa, sección 'retencion' del JSON)
# ========================================

def _es_sociedad(nit):
    """Heurística de NIT jurídico colombiano: 9 dígitos que inician en 8 o 9.
    Las personas naturales (cédulas) y sociedades con NIT atípico no matchean
    aquí y deben estar en la lista explícita agentes_nit."""
    nit = str(nit).strip()
    return len(nit) == 9 and nit[0] in '89'


def _retencion_compra(nit, base, cfg_compras):
    """Retefuente que la empresa practica al comprar mercancía. Retorna el
    valor a retener (>=0). cfg_compras = retencion.compras del JSON."""
    if not cfg_compras:
        return 0.0
    if str(nit).strip() in set(cfg_compras.get('excluir_nits', [])):
        return 0.0
    if base < cfg_compras.get('base_minima', 0):
        return 0.0
    return round(base * cfg_compras.get('rate', 0), 0)


def _retenciones_venta(nit, base, iva, cfg_ventas):
    """Retenciones que un cliente practica a la empresa en una venta.
    Retorna (retefuente, reteiva). cfg_ventas = retencion.ventas del JSON."""
    if not cfg_ventas:
        return 0.0, 0.0
    nit = str(nit).strip()
    es_agente = nit in set(cfg_ventas.get('agentes_nit', [])) or _es_sociedad(nit)
    if not es_agente:
        return 0.0, 0.0

    rf = cfg_ventas.get('retefuente', {})
    retefuente = 0.0
    if base >= rf.get('base_minima', 0):
        retefuente = round(base * rf.get('rate', 0), 0)

    ri = cfg_ventas.get('reteiva', {})
    reteiva = 0.0
    if nit in set(ri.get('nits', [])) and abs(iva) > 0.01 and base >= ri.get('base_minima', 0):
        reteiva = round(iva * ri.get('rate', 0), 0)

    return retefuente, reteiva


def _escribir_ventas(ws, row_idx, ventas, nc_ventas, cuentas, comp, ret_ventas=None):
    """Escribe las líneas de facturas de venta y sus notas crédito, con las
    cuentas e ingresos por tarifa del JSON de la empresa."""
    for v in ventas:
        if abs(v['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(v['fecha'])
        folio  = v['folio']
        nit    = v['nit']
        nombre = v['nombre']
        base   = v['gravado']
        iva    = v['iva']
        total  = v['total']
        tarifa = _clasificar_tarifa_venta(base, iva)
        cta_ingreso = _cuenta_compra(cuentas, 'cuenta_ingreso', tarifa)
        cta_iva     = _cuenta_compra(cuentas, 'cuenta_iva_generado', tarifa)
        retefuente, reteiva = _retenciones_venta(nit, base, iva, ret_ventas)

        partes = _partes_tarifa(v, base, iva) or [(tarifa, base, iva)]
        # Ingreso (crédito): una línea por tarifa (no gravado, 19 %, 5 %)
        for t, b_t, _i in partes:
            if abs(b_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_compra(cuentas, 'cuenta_ingreso', t), comp['venta'], fecha, folio, nit,
                    'VENTAS', TIPO_CREDITO, b_t, nombre=nombre))
                row_idx += 1

        # IVA generado (crédito) — una línea por tarifa con IVA
        for t, b_t, i_t in partes:
            if abs(i_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_compra(cuentas, 'cuenta_iva_generado', t), comp['venta'], fecha, folio,
                    nit, 'VENTAS', TIPO_CREDITO, i_t, base=b_t, nombre=nombre))
                row_idx += 1

        # Retención en la fuente que el cliente nos practica (débito, anticipo)
        if retefuente > 0.01:
            _escribir_fila(ws, row_idx, _fila_contai(
                ret_ventas['retefuente']['cuenta_anticipo'], comp['venta'], fecha, folio,
                nit, 'RTE FTE VENTAS', TIPO_DEBITO, retefuente, base=base, nombre=nombre))
            row_idx += 1

        # Retención de IVA que el cliente nos practica (débito, anticipo)
        if reteiva > 0.01:
            _escribir_fila(ws, row_idx, _fila_contai(
                ret_ventas['reteiva']['cuenta_anticipo'], comp['venta'], fecha, folio,
                nit, 'RTE IVA VENTAS', TIPO_DEBITO, reteiva, base=iva, nombre=nombre))
            row_idx += 1

        # Clientes / CxC (o Caja de contado) — débito por el neto recibido
        # (total menos lo retenido por el cliente)
        _escribir_fila(ws, row_idx, _fila_contai(
            cuentas['cuenta_clientes'], comp['venta'], fecha, folio, nit, 'VENTAS',
            TIPO_DEBITO, total - retefuente - reteiva, nombre=nombre))
        row_idx += 1

    for nc in nc_ventas:
        if abs(nc['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(nc['fecha'])
        folio  = nc['folio']
        nit    = nc['nit']
        nombre = nc['nombre']
        base   = nc['gravado']
        iva    = nc['iva']
        total  = nc['total']
        tarifa = _clasificar_tarifa_venta(base, iva)
        # Cuenta de devolución según tarifa; si la empresa no tiene cuenta
        # de devoluciones configurada, se reversa contra la de ingreso.
        cta_dev = (_cuenta_compra(cuentas, 'cuenta_dev_ventas', tarifa)
                   or _cuenta_compra(cuentas, 'cuenta_ingreso', tarifa))
        cta_iva_dev = (cuentas.get('cuenta_iva_dev')
                       or _cuenta_compra(cuentas, 'cuenta_iva_generado', tarifa))

        # Devolución en ventas (débito)
        _escribir_fila(ws, row_idx, _fila_contai(
            cta_dev, comp['nc_venta'], fecha, folio, nit, 'DEV. VENTAS',
            TIPO_DEBITO, base, nombre=nombre))
        row_idx += 1

        # IVA en devoluciones (débito) — solo si hay IVA
        if abs(iva) > 0.01:
            _escribir_fila(ws, row_idx, _fila_contai(
                cta_iva_dev, comp['nc_venta'], fecha, folio, nit, 'DEV. VENTAS',
                TIPO_DEBITO, iva, base=base, nombre=nombre))
            row_idx += 1

        # Clientes / CxC (crédito) por el total
        _escribir_fila(ws, row_idx, _fila_contai(
            cuentas['cuenta_clientes'], comp['nc_venta'], fecha, folio, nit, 'DEV. VENTAS',
            TIPO_CREDITO, total, nombre=nombre))
        row_idx += 1

    return row_idx


def _clasificar_tarifa_compra(base, iva):
    """
    Igual que _clasificar_tarifa_venta pero para compras: el reporte DIAN
    trae base e IVA por documento, así que la tarifa efectiva (iva/base) se
    calcula por factura. Retorna '0', '5' o '19' (sufijo de la clave
    cuenta_compras_<tarifa> / cuenta_dev_compras_<tarifa> en el JSON de
    la empresa).
    """
    if abs(iva) < 0.01:
        return '0'
    rate = iva / base if abs(base) > 0.01 else 1.0
    if rate < 0.12:
        return '5'
    return '19'


# Concepto (col. descripción) según la tarifa efectiva de la compra, para que
# el plano muestre la cuenta a la que corresponde cada línea.
_CONCEPTO_COMPRA = {'5': 'COMPRAS GRAVADAS 5%', '0': 'COMPRAS NO GRAVADAS',
                    '19': 'COMPRAS GRAVADAS 19%'}
_CONCEPTO_DEV_COMPRA = {'5': 'DEV. COMPRAS GRAV. 5%', '0': 'DEV. COMPRAS NO GRAVADAS',
                        '19': 'DEV. COMPRAS GRAV. 19%'}


def _partes_tarifa(doc, base, iva):
    """[(tarifa, base, iva)] de UN documento partido por tarifa con lo que el Lector leyó del XML
    (base_19/5/0, iva_19/5), cuadrado contra la base y el IVA del documento. None si el reporte
    no trae el detalle o no cuadra → se escribe como antes (una sola tarifa efectiva).
    15-oct (Multiabarrotes): 33 de 35 ventas y 17 de 35 compras de un supermercado mezclan
    19 %, 5 % y excluido, y el plano las mandaba enteras a una sola cuenta."""
    if 'base_19' not in doc and 'iva_19' not in doc:
        return None
    b = {'19': float(doc.get('base_19') or 0), '5': float(doc.get('base_5') or 0),
         '0': float(doc.get('base_0') or 0)}
    i = {'19': float(doc.get('iva_19') or 0), '5': float(doc.get('iva_5') or 0), '0': 0.0}
    if sum(abs(v) for v in b.values()) < 0.01:
        return None
    di = round(iva - i['19'] - i['5'], 2)                  # el IVA del documento manda
    if abs(di) > 0.01:
        if abs(di) > max(1.0, 0.01 * abs(iva)):
            return None
        k = '19' if abs(i['19']) >= abs(i['5']) else '5'
        i[k] = round(i[k] + di, 2)
    db = round(base - sum(b.values()), 2)                 # y la base del documento también
    if abs(db) > 0.01:
        if abs(db) > max(1.0, 0.01 * abs(base)):
            b['0'] = round(b['0'] + db, 2)                # lo que no es 19 ni 5 es no gravado
        else:
            k = max(b, key=lambda t: abs(b[t]))
            b[k] = round(b[k] + db, 2)
    if b['0'] < -0.01:
        return None
    return [(t, round(b[t], 2), round(i[t], 2)) for t in ('19', '5', '0')
            if abs(b[t]) > 0.01 or abs(i[t]) > 0.01]


def _cuenta_compra(cuentas, prefijo, tarifa):
    """Busca cuentas[f'{prefijo}_{tarifa}']; si la empresa no tiene esa
    cuenta configurada (ej. sin compras no gravadas), usa la de 19% como
    mejor aproximación disponible — nunca deja de escribir el valor."""
    return cuentas.get(f'{prefijo}_{tarifa}') or cuentas.get(f'{prefijo}_19')


def _cuenta_iva_desc(cuentas, *claves):
    """IVA descontable por flujo: prueba las claves específicas en orden
    (ej. cuenta_iva_descontable_compras_19) y cae a la genérica
    cuenta_iva_descontable. Permite balances cuyo nivel transaccional
    separa el IVA por compras/gastos/devoluciones (auxiliares de 8 dígitos,
    ej. INVERPLAS 24080204/24080208)."""
    for clave in claves:
        if cuentas.get(clave):
            return cuentas[clave]
    return cuentas['cuenta_iva_descontable']


def _escribir_compras(ws, row_idx, compras, cuentas, comp, ret_compras=None,
                      ret_proveedor=None):
    """Escribe las líneas de facturas de compra (mercancía/inventario),
    separadas por tarifa efectiva (no gravada/5%/19%) de cada factura."""
    for c in compras:
        if abs(c['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(c['fecha'])
        folio  = c['folio']
        nit    = c['nit']
        nombre = c['nombre']
        base   = c['gravado']
        iva    = c['iva']
        total  = c['total']
        tarifa = _clasificar_tarifa_compra(base, iva)
        cta_compra = _cuenta_compra(cuentas, 'cuenta_compras', tarifa)
        retefuente = _retencion_compra(nit, base, ret_compras)
        cta_ret = (ret_compras or {}).get('cuenta')
        if ret_proveedor:                      # lo que el contador parametrizó
            _r = ret_proveedor(nit, base)      # (cuenta, valor, etiqueta) o None
            if _r and _r[1] > 0.01:
                cta_ret, retefuente = _r[0], _r[1]

        # Impuesto al consumo pagado (no descontable): sigue siendo mayor valor
        # de la compra, pero va a SU cuenta si el contador la parametrizó, para
        # poder identificarlo en el formato 1001. Sin cuenta, queda como antes
        # (sumado dentro de la línea de compras).
        inc = round(float(c.get('inc') or 0), 2)
        cta_inc = (cuentas or {}).get('cuenta_inc_compras')
        if inc > 0.01 and cta_inc:
            base = round(base - inc, 2)
        else:
            inc = 0.0

        partes = _partes_tarifa(c, base, iva) or [(tarifa, base, iva)]
        # Compras gravadas o no gravadas (débito): una línea por tarifa de la factura
        for t, b_t, _i in partes:
            if abs(b_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_compra(cuentas, 'cuenta_compras', t), comp['compra'], fecha, folio, nit,
                    _CONCEPTO_COMPRA.get(t, 'COMPRAS GRAVADAS 19%'),
                    TIPO_DEBITO, b_t, nombre=nombre))
                row_idx += 1

        if inc:
            _escribir_fila(ws, row_idx, _fila_contai(
                cta_inc, comp['compra'], fecha, folio, nit, 'IMPUESTO AL CONSUMO',
                TIPO_DEBITO, inc, nombre=nombre))
            row_idx += 1

        # IVA descontable (débito) — una línea por tarifa con IVA, en su cuenta
        for t, b_t, i_t in partes:
            if abs(i_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_iva_desc(cuentas, f'cuenta_iva_descontable_compras_{t}',
                                     'cuenta_iva_descontable_compras_19', 'cuenta_iva_descontable_compras'),
                    comp['compra'], fecha, folio, nit, 'COMPRAS',
                    TIPO_DEBITO, i_t, base=b_t, nombre=nombre))
                row_idx += 1

        # Retefuente que le practicamos al proveedor (crédito, retención por pagar)
        if retefuente > 0.01 and cta_ret:
            _escribir_fila(ws, row_idx, _fila_contai(
                cta_ret, comp['compra'], fecha, folio, nit, 'RTE FTE COMPRAS',
                TIPO_CREDITO, retefuente, base=base, nombre=nombre))
            row_idx += 1

        # Proveedores / CxP / Caja (crédito) por el neto pagado (total − retención)
        _escribir_fila(ws, row_idx, _fila_contai(
            cuentas['cuenta_proveedores'], comp['compra'], fecha, folio, nit, 'COMPRAS',
            TIPO_CREDITO, total - retefuente, nombre=nombre))
        row_idx += 1

    return row_idx


def _escribir_nc_compras(ws, row_idx, nc_compras, cuentas, comp):
    """Escribe las líneas de notas crédito de compra (devoluciones a proveedor),
    separadas por tarifa efectiva igual que _escribir_compras."""
    for nc in nc_compras:
        if abs(nc['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(nc['fecha'])
        folio  = nc['folio']
        nit    = nc['nit']
        nombre = nc['nombre']
        base   = nc['gravado']
        iva    = nc['iva']
        total  = nc['total']
        tarifa = _clasificar_tarifa_compra(base, iva)
        cta_dev = _cuenta_compra(cuentas, 'cuenta_dev_compras', tarifa)

        partes = _partes_tarifa(nc, base, iva) or [(tarifa, base, iva)]
        # Devolución en compras (crédito): una línea por tarifa
        for t, b_t, _i in partes:
            if abs(b_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_compra(cuentas, 'cuenta_dev_compras', t), comp['nc_compra'], fecha, folio, nit,
                    _CONCEPTO_DEV_COMPRA.get(t, 'DEV. COMPRAS GRAV. 19%'),
                    TIPO_CREDITO, b_t, nombre=nombre))
                row_idx += 1

        # IVA en devolución de compras (crédito) — una línea por tarifa con IVA
        for t, b_t, i_t in partes:
            if abs(i_t) > 0.01:
                _escribir_fila(ws, row_idx, _fila_contai(
                    _cuenta_iva_desc(cuentas, f'cuenta_iva_dev_compras_{t}', 'cuenta_iva_dev_compras'),
                    comp['nc_compra'], fecha, folio, nit, 'DEV. COMPRAS',
                    TIPO_CREDITO, i_t, base=b_t, nombre=nombre))
                row_idx += 1

        # Proveedores / CxP (débito) por el total
        _escribir_fila(ws, row_idx, _fila_contai(
            cuentas['cuenta_proveedores'], comp['nc_compra'], fecha, folio, nit, 'DEV. COMPRAS',
            TIPO_DEBITO, total, nombre=nombre))
        row_idx += 1

    return row_idx


def _clasificar_recibidos(empresa_nit, compras_raw, gastos_raw, notas_credito_raw):
    """
    Reclasifica TODOS los documentos recibidos (facturas + NC) de la empresa
    usando el clasificador híbrido (reglas -> caché -> IA, ver classifiers/).
    La clasificación de converter.py (compras_raw/gastos_raw, basada en
    NIT_PROVEEDOR_INVENTARIO de un solo cliente) se ignora aquí — cada
    empresa tiene su propio archivo de reglas (reglas_empresas/<nit>.json).

    Retorna (compras, gastos, nc_compras, nc_gastos, pendientes, resumen_fuentes).
    Los docs de gastos/nc_gastos traen además 'cuenta_asignada'.
    """
    reglas_empresa = cargar_reglas(empresa_nit)
    tipo_default = reglas_empresa.get('tipo_default_recibidos') or 'gasto'

    facturas = compras_raw + gastos_raw
    resultados_facturas = clasificar_lote_documentos(empresa_nit, facturas, tipo_default=tipo_default)
    resultados_nc = clasificar_lote_documentos(empresa_nit, notas_credito_raw, tipo_default=tipo_default)

    compras, gastos, pendientes = [], [], []
    resumen_fuentes = {'regla': 0, 'cache': 0, 'ia': 0, 'default': 0}

    def _procesar(doc, res, destino_compras, destino_gastos):
        resumen_fuentes[res['fuente']] = resumen_fuentes.get(res['fuente'], 0) + 1
        if res['tipo'] == 'compra':
            destino_compras.append(doc)
        else:
            destino_gastos.append({**doc, 'cuenta_asignada': res['cuenta']})
        if res['pendiente']:
            pendientes.append({**doc, 'cuenta': res['cuenta'],
                                'confianza': res['confianza'],
                                'justificacion': res['justificacion']})

    for doc, res in zip(facturas, resultados_facturas):
        _procesar(doc, res, compras, gastos)

    nc_compras, nc_gastos = [], []
    for doc, res in zip(notas_credito_raw, resultados_nc):
        _procesar(doc, res, nc_compras, nc_gastos)

    return compras, gastos, nc_compras, nc_gastos, pendientes, resumen_fuentes


def _escribir_nc_gastos(ws, row_idx, nc_gastos, cuenta_iva_descontable, cuenta_proveedores, comp):
    """Escribe notas crédito de gastos/servicios (devolución al proveedor)."""
    for nc in nc_gastos:
        if abs(nc['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(nc['fecha'])
        folio  = nc['folio']
        nit    = nc['nit']
        nombre = nc['nombre']
        base   = nc['gravado']
        iva    = nc['iva']
        total  = nc['total']
        cuenta_gasto = nc['cuenta_asignada']
        # Igual que en gastos: si la cuenta es de inventario, es devolución de COMPRAS
        det = 'DEV. COMPRAS' if str(cuenta_gasto or "").startswith("14") else 'DEV. GASTOS'

        # Reverso de la cuenta de gasto (crédito)
        _escribir_fila(ws, row_idx, _fila_contai(
            cuenta_gasto, comp['nc_compra'], fecha, folio, nit, det,
            TIPO_CREDITO, base, nombre=nombre))
        row_idx += 1

        # Reverso IVA descontable (crédito) — solo si hay IVA
        if abs(iva) > 0.01:
            _escribir_fila(ws, row_idx, _fila_contai(
                cuenta_iva_descontable, comp['nc_compra'], fecha, folio, nit, det,
                TIPO_CREDITO, iva, base=base, nombre=nombre))
            row_idx += 1

        # Proveedores / CxP (débito) por el total
        _escribir_fila(ws, row_idx, _fila_contai(
            cuenta_proveedores, comp['nc_compra'], fecha, folio, nit, det,
            TIPO_DEBITO, total, nombre=nombre))
        row_idx += 1

    return row_idx


def _escribir_gastos(ws, row_idx, gastos, cuenta_iva_descontable, cuenta_proveedores, comp,
                     ret_proveedor=None, cuentas_extra=None):
    """Escribe las líneas de facturas de gastos/servicios. Cada doc ya trae
    su 'cuenta_asignada' (resuelta por classifiers: regla, caché o IA)."""
    for g in gastos:
        if abs(g['total']) < 0.01:
            continue
        fecha  = _fmt_fecha(g['fecha'])
        folio  = g['folio']
        nit    = g['nit']
        nombre = g['nombre']
        base   = g['gravado']
        iva    = g['iva']
        total  = g['total']
        cuenta_gasto = g['cuenta_asignada']
        # Lo que entra a INVENTARIO (cuenta 14xx) es una COMPRA, no un gasto: va con
        # el comprobante de compras y su detalle dice COMPRAS. Antes todo lo recibido
        # salía como «GASTOS» aunque la cuenta fuera de mercancía.
        es_compra = str(cuenta_gasto or "").startswith("14")
        comp_doc = comp['compra'] if es_compra else comp['gasto']
        det = 'COMPRAS' if es_compra else 'GASTOS'
        det_ret = 'RTE FTE COMPRAS' if es_compra else 'RTE FTE GASTOS'
        # Retención que la empresa le practica a ESE proveedor (parametrizada)
        retefuente, cta_ret = 0.0, None
        if ret_proveedor:
            _r = ret_proveedor(nit, base)
            if _r and _r[1] > 0.01:
                cta_ret, retefuente = _r[0], _r[1]

        # Impuesto al consumo pagado (restaurantes, bares): mayor valor del gasto
        # pero en su propia cuenta cuando está parametrizada (formato 1001).
        inc = round(float(g.get('inc') or 0), 2)
        cta_inc = (cuentas_extra or {}).get('cuenta_inc_compras') if cuentas_extra else None
        if inc > 0.01 and cta_inc:
            base = round(base - inc, 2)
        else:
            inc = 0.0

        # Cuenta de gasto (débito)
        _escribir_fila(ws, row_idx, _fila_contai(
            cuenta_gasto, comp_doc, fecha, folio, nit, det,
            TIPO_DEBITO, base, nombre=nombre))
        row_idx += 1

        if inc:
            _escribir_fila(ws, row_idx, _fila_contai(
                cta_inc, comp_doc, fecha, folio, nit, 'IMPUESTO AL CONSUMO',
                TIPO_DEBITO, inc, nombre=nombre))
            row_idx += 1

        # IVA descontable (débito) — solo si hay IVA
        if abs(iva) > 0.01:
            _escribir_fila(ws, row_idx, _fila_contai(
                cuenta_iva_descontable, comp_doc, fecha, folio, nit, det,
                TIPO_DEBITO, iva, base=base, nombre=nombre))
            row_idx += 1

        # Retención en la fuente practicada (crédito)
        if retefuente > 0.01 and cta_ret:
            _escribir_fila(ws, row_idx, _fila_contai(
                cta_ret, comp_doc, fecha, folio, nit, det_ret,
                TIPO_CREDITO, retefuente, base=base, nombre=nombre))
            row_idx += 1

        # Proveedores / CxP (crédito) por el total MENOS la retención
        _escribir_fila(ws, row_idx, _fila_contai(
            cuenta_proveedores, comp_doc, fecha, folio, nit, det,
            TIPO_CREDITO, round(total - retefuente, 2), nombre=nombre))
        row_idx += 1

    return row_idx


def _excel_a_txt_contai(wb):
    """Convierte un Excel plano Contai a formato .txt tab-delimitado.

    Lee la hoja 'ARCHIVO PLANO' del workbook y la exporta como texto
    con headers y filas separadas por TABs (formato que Contai acepta).
    """
    ws = wb['ARCHIVO PLANO']
    filas = ws.iter_rows(values_only=True)

    # El TXT es un ESPEJO del Excel en columnas, pero SIN la fila de encabezado:
    # Contai la importa como un registro más y la reporta con inconsistencias
    # («Cuenta», «//», «Nit»… no son datos). El Excel sí la conserva, que es el
    # que se revisa a ojo.
    cabecera = [str(v) if v is not None else '' for v in next(filas, ())]
    ancho = len(cabecera)
    lineas = []

    # Filas de datos: todas las que tengan contenido
    for row in filas:
        if not row or all(v is None or v == '' for v in row[:9]):
            continue  # Saltar filas vacías o sin datos
        vals = list(row[:ancho]) + [None] * max(0, ancho - len(row))
        # Convertir fechas al formato dd-mm-yyyy si es necesario
        if len(vals) > 2 and vals[2]:
            try:
                from datetime import datetime
                if isinstance(vals[2], datetime):
                    vals[2] = vals[2].strftime('%d/%m/%Y')
            except:
                pass
        # Convertir valores a strings, vacíos si None
        fila = '\t'.join(str(v) if v is not None else '' for v in vals)
        lineas.append(fila)

    # CRLF: el archivo de muestra generado por Contai usa terminadores Windows
    txt_bytes = '\r\n'.join(lineas).encode('latin-1', errors='replace')
    return io.BytesIO(txt_bytes)


HEADERS_TERCEROS = [
    'Nit', 'Tipo', 'Nombre', 'Direccion', 'Ciudad', 'Telefono', 'Municipio',
    'Activo', 'Tiene RUT', 'Pais', 'Email', 'Celular', 'Plazo',
    'Actividad Económica', 'Indicativo', 'Naturaleza'
]

# NITs que no se crean como terceros (genéricos / consumidor final)
_NITS_GENERICOS = {'222222222222', '0', '', 'None', 'none'}


def _generar_terceros_txt(mi_nit, *listas_docs):
    """Genera el plano de creación de NITs (terceros) para Contai en .txt
    tab-delimitado, según el formato oficial 'FORMATO CREAR NITS' (16
    columnas: Nit, Tipo C/N, Nombre, ..., Activo=S, Tiene RUT=N, Pais=169,
    Plazo=0). Recolecta los NITs únicos de todas las listas de documentos
    (compras, gastos, NC, ventas) con su nombre.
    """
    terceros = {}  # nit -> nombre (se queda con el nombre más largo visto)
    for docs in listas_docs:
        for d in docs or []:
            nit = str(d.get('nit') or '').strip()
            if not nit or nit in _NITS_GENERICOS or nit == str(mi_nit):
                continue
            nombre = str(d.get('nombre') or '').strip().upper()
            if nit not in terceros or len(nombre) > len(terceros[nit]):
                terceros[nit] = nombre

    lineas = ['\t'.join(HEADERS_TERCEROS)]
    for nit in sorted(terceros):
        nombre = terceros[nit] or f'TERCERO {nit}'
        tipo = 'N' if _es_sociedad(nit) else 'C'
        fila = [nit, tipo, nombre, '', '', '', '',
                'S', 'N', '169', '', '', '0', '', '', '']
        lineas.append('\t'.join(fila))

    return io.BytesIO('\r\n'.join(lineas).encode('latin-1', errors='replace'))


def generar_plano_contai_completo(input_stream, incluir=('ventas', 'compras', 'nc_compras', 'gastos'),
                                  ret_proveedor=None):
    """
    Lee el reporte DIAN y genera el plano contable completo en formato Contai
    (ventas, compras, notas crédito de compras y gastos, según lo solicitado
    en 'incluir'). La clasificación compra/gasto usa classifiers/ (reglas por
    empresa -> caché -> IA), no cuentas hardcodeadas de un solo cliente.

    Retorna un dict: {'plano': BytesIO, 'empresa_nit': str, 'pendientes': [...],
    'resumen': {'por_regla': n, 'por_cache': n, 'por_ia': n, 'pendientes': n}}
    """
    from converter import leer_documentos_auto
    (mi_nit, facturas_compras_raw, facturas_gastos_raw, notas_credito_raw,
     ventas, nc_ventas, _, _, _, _, _, _) = leer_documentos_auto(input_stream)

    cuentas = cargar_reglas(mi_nit)
    comp = {**COMPROBANTES_DEFAULT, **(cuentas.get('comprobantes') or {})}
    retencion = cuentas.get('retencion') or {}
    ret_compras = retencion.get('compras')
    ret_ventas = retencion.get('ventas')

    faltantes = []
    if 'compras' in incluir or 'gastos' in incluir or 'nc_compras' in incluir:
        # Mínimo indispensable: cuenta_compras_19 y cuenta_dev_compras_19 son
        # el fallback de cualquier tarifa no configurada explícitamente
        # (ver _cuenta_compra), así que son las únicas realmente obligatorias.
        faltantes += [c for c in ('cuenta_compras_19', 'cuenta_proveedores',
                                   'cuenta_iva_descontable', 'cuenta_dev_compras_19')
                      if not cuentas.get(c)]
    if 'ventas' in incluir:
        faltantes += [c for c in ('cuenta_ingreso_19', 'cuenta_iva_generado_19',
                                   'cuenta_clientes')
                      if not cuentas.get(c)]
    if faltantes:
        raise ValueError(
            f"La empresa con NIT {mi_nit} no tiene configuradas las cuentas "
            f"{faltantes} en reglas_empresas/{mi_nit}.json. Configúralas antes "
            f"de generar el plano para esta empresa (no se asumen las "
            f"cuentas de otra empresa)."
        )

    compras, gastos, nc_compras, nc_gastos, pendientes, resumen_fuentes = _clasificar_recibidos(
        mi_nit, facturas_compras_raw, facturas_gastos_raw, notas_credito_raw)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'ARCHIVO PLANO'
    _escribir_headers(ws)

    row_idx = 2
    if 'ventas' in incluir:
        row_idx = _escribir_ventas(ws, row_idx, ventas, nc_ventas, cuentas, comp, ret_ventas)
    if 'compras' in incluir:
        row_idx = _escribir_compras(ws, row_idx, compras, cuentas, comp, ret_compras,
                                    ret_proveedor=ret_proveedor)
    if 'gastos' in incluir:
        row_idx = _escribir_gastos(ws, row_idx, gastos,
                                    _cuenta_iva_desc(cuentas, 'cuenta_iva_descontable_gastos'),
                                    cuentas['cuenta_proveedores'], comp,
                                    ret_proveedor=ret_proveedor, cuentas_extra=cuentas)
    if 'nc_compras' in incluir:
        row_idx = _escribir_nc_compras(ws, row_idx, nc_compras, cuentas, comp)
        row_idx = _escribir_nc_gastos(ws, row_idx, nc_gastos,
                                       _cuenta_iva_desc(cuentas, 'cuenta_iva_dev_gastos'),
                                       cuentas['cuenta_proveedores'], comp)

    # Ajustar ancho de columnas
    anchos = [10, 12, 16, 12, 14, 14, 24, 14, 6, 14, 14, 14, 12, 8]
    for col_idx, ancho in enumerate(anchos, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = ancho

    output = io.BytesIO()
    wb.save(output)
    output = io.BytesIO(output.getvalue())  # BytesIO nuevo, íntegro y en posición 0

    # TXT tab-delimitado (formato que Contai importa nativamente).
    # Se genera DESPUÉS de wb.save() para no interferir con el Excel.
    output_txt = io.BytesIO(_excel_a_txt_contai(wb).getvalue())

    # Plano de creación de terceros (NITs) con todos los NITs del reporte
    terceros_txt = _generar_terceros_txt(
        mi_nit, ventas, nc_ventas, compras, gastos, nc_compras, nc_gastos)

    resumen = {**resumen_fuentes, 'total_pendientes': len(pendientes)}
    return {
        'plano': output,        # Excel (.xlsx) — para verificar visualmente
        'plano_txt': output_txt,  # Texto tab-delimitado (.txt) — para importar
        'terceros_txt': terceros_txt,  # Plano crear NITs (.txt) — para importar
        'empresa_nit': mi_nit,
        'pendientes': pendientes,
        'resumen': resumen
    }


def generar_plano_contai(input_stream, incluir=('ventas', 'compras', 'nc_compras', 'gastos')):
    """Genera plano Contai en formato Excel. Retorna BytesIO limpio y listo para descargar."""
    resultado = generar_plano_contai_completo(input_stream, incluir=incluir)
    plano_original = resultado['plano']
    # Garantizar que el BytesIO está limpio y desde el inicio
    plano_original.seek(0)
    bytes_contenido = plano_original.read()
    # Retornar un BytesIO nuevo con los bytes
    nuevo_stream = io.BytesIO(bytes_contenido)
    nuevo_stream.seek(0)
    return nuevo_stream


def generar_plano_ventas_contai(input_stream):
    """Compatibilidad: genera solo el plano de ventas en formato Contai."""
    return generar_plano_contai(input_stream, incluir=('ventas',))
