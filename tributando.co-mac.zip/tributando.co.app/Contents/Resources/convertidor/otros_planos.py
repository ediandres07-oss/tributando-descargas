"""Planos para otros programas contables (World Office, Helisa, Genérico, Alegra, Loggro, Siigo Pyme).

El plano Siigo es el intermedio canónico: cada fila ya es un movimiento de
doble partida (cuenta, tercero, débito/crédito, base) con las reglas de cuentas
y retenciones del cliente aplicadas. Aquí solo lo RE-SERIALIZAMOS al formato de
importación de cada programa, sin recalcular nada — así el asiento es idéntico
al de Siigo/Contai y solo cambian las columnas del archivo.

Ambos importadores (World Office «Importar contabilidad» y Helisa «Importar
comprobantes») permiten mapear columnas al importar, así que el orden aquí sigue
el layout estándar y se puede ajustar a la plantilla exacta de cada versión.
"""
from __future__ import annotations

import io
from datetime import datetime, date

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

_BORDE = Border(*(Side(style="thin", color="BFCCD8"),) * 4)


def _num(v) -> float:
    try:
        return round(float(v), 2)
    except (TypeError, ValueError):
        return 0.0


def _fmt_fecha(v) -> str:
    """Fecha en dd/MM/yyyy (formato que aceptan World Office y Helisa)."""
    if isinstance(v, (datetime, date)):
        return v.strftime("%d/%m/%Y")
    s = str(v or "").strip()
    if not s:
        return ""
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
                "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s[:len(fmt) + 2], fmt).strftime("%d/%m/%Y")
        except ValueError:
            continue
    return s


# Hoja del plano Siigo → grupo de comprobante. Las ventas del convertidor salen
# consolidadas por cliente y con las cuentas por defecto de Siigo (13050501,
# 41009501, 24080501), no con las del cliente: por eso los demás programas solo
# re-serializan compras, gastos y notas crédito de compras.
GRUPO_HOJA = {"COMPRAS": "compras", "NC COMPRAS": "nc", "GASTOS": "gastos",
              "VENTAS": "ventas", "NC VENTAS": "nc_ventas"}
HOJAS_COMPRAS = ("COMPRAS", "NC COMPRAS", "GASTOS")


def _leer_siigo(xlsx_bytes: bytes, hojas=HOJAS_COMPRAS) -> list[dict]:
    """Lee el plano Siigo (.xlsx) y devuelve la lista de movimientos.

    Recorre TODAS las hojas de movimiento (COMPRAS, NC COMPRAS, GASTOS…), no solo
    la activa: antes solo se leía la primera y las demás se perdían en silencio.
    `hojas`: nombres de hoja a incluir (None = todas las que tengan movimientos;
    un plano de una sola hoja sin nombre de grupo también se lee completo).
    Localiza las columnas por nombre (tolerante a tildes/orden), igual que
    helisa_api.asiento_desde_plano_siigo, para no romperse si cambia el layout.
    """
    wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), read_only=True, data_only=True)
    permitidas = {h.upper() for h in hojas} if hojas else None
    movs = []
    for nombre_hoja in wb.sheetnames:
        grupo = GRUPO_HOJA.get(nombre_hoja.strip().upper())
        if permitidas is not None and grupo is not None and nombre_hoja.strip().upper() not in permitidas:
            continue
        filas = list(wb[nombre_hoja].iter_rows(values_only=True))
        if not filas or str(filas[0][0] or "").strip().lower() != "tipo de comprobante":
            continue
        movs.extend(_movs_de_hoja(filas, grupo))
    return movs


def _movs_de_hoja(filas, grupo) -> list[dict]:
    cab = [str(c or "").strip().lower() for c in filas[0]]

    def col(*nombres):
        for n in nombres:
            for i, c in enumerate(cab):
                if n in c:
                    return i
        return None

    c_tipo = col("tipo de comprobante")
    c_num = col("consecutivo comprobante")
    c_fec = col("fecha de elaboración", "fecha de elaboracion")
    c_cta = col("código cuenta", "codigo cuenta")
    c_ter = col("identificación tercero", "identificacion tercero")
    c_pref = col("prefijo")
    c_imp = col("código impuesto", "codigo impuesto")
    c_des = col("descripción", "descripcion")
    c_cc = col("centro/subcentro", "centro de costos")
    c_deb = col("débito", "debito")
    c_cre = col("crédito", "credito")
    c_base = col("base gravable")

    def g(row, idx):
        return row[idx] if idx is not None and idx < len(row) else None

    movs = []
    for row in filas[1:]:
        if c_cta is None:
            break
        cuenta = str(g(row, c_cta) or "").strip()
        if not cuenta:
            continue
        deb = _num(g(row, c_deb))
        cre = _num(g(row, c_cre))
        if not deb and not cre:
            continue
        nit = g(row, c_ter)
        fecha = g(row, c_fec)
        movs.append({
            "grupo": grupo,
            "tipo": str(g(row, c_tipo) or "").strip(),
            "num": str(g(row, c_num) or "").strip(),
            "prefijo": str(g(row, c_pref) or "").strip(),
            "fecha": _fmt_fecha(fecha),
            "fecha_dt": fecha.date() if isinstance(fecha, datetime) else (fecha if isinstance(fecha, date) else None),
            "cuenta": cuenta,
            "nit": str(nit).strip() if nit else "",
            "cod_imp": g(row, c_imp),
            "detalle": str(g(row, c_des) or "").strip(),
            "cc": str(g(row, c_cc) or "").strip(),
            "debito": deb,
            "credito": cre,
            "base": _num(g(row, c_base)),
        })
    return movs


def _escribir(headers, filas, hoja: str) -> bytes:
    """Arma un .xlsx con encabezados con estilo y las filas de movimiento."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = hoja
    fill = PatternFill(fill_type="solid", fgColor="1a3a5c")
    font = Font(bold=True, color="FFFFFF", name="Calibri", size=10)
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _BORDE
    ws.row_dimensions[1].height = 22
    for r, fila in enumerate(filas, 2):
        for c, val in enumerate(fila, 1):
            cell = ws.cell(row=r, column=c, value=val)
            cell.border = _BORDE
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.00"
    # anchos aproximados
    for c, h in enumerate(headers, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = max(11, min(30, len(h) + 3))
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ── World Office ──────────────────────────────────────────────────────────────
HEADERS_WO = [
    "Tipo de comprobante", "Prefijo", "Número", "Fecha", "Cuenta contable",
    "Identificación tercero", "Concepto", "Débito", "Crédito",
    "Base", "Centro de costo",
]


def siigo_a_worldoffice(xlsx_siigo: bytes) -> bytes:
    """Convierte el plano Siigo al Excel de importación de World Office.

    Cada fila es una línea del comprobante contable; World Office agrupa por
    (Tipo + Prefijo + Número) al importar.
    """
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        filas.append([
            m["tipo"], m["prefijo"], m["num"], m["fecha"], m["cuenta"],
            m["nit"], m["detalle"],
            m["debito"] or None, m["credito"] or None,
            m["base"] or None, m["cc"] or None,
        ])
    return _escribir(HEADERS_WO, filas, "Contabilidad")


# ── Helisa ────────────────────────────────────────────────────────────────────
HEADERS_HELISA = [
    "Comprobante", "Número", "Fecha", "Cuenta", "Nit", "Detalle",
    "Débito", "Crédito", "Base", "Centro de costo",
]


def siigo_a_helisa(xlsx_siigo: bytes) -> bytes:
    """Convierte el plano Siigo al Excel de importación de comprobantes de Helisa."""
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        filas.append([
            m["tipo"], m["num"], m["fecha"], m["cuenta"], m["nit"], m["detalle"],
            m["debito"] or None, m["credito"] or None,
            m["base"] or None, m["cc"] or None,
        ])
    return _escribir(HEADERS_HELISA, filas, "Comprobantes")


# ── Genérico / estándar ───────────────────────────────────────────────────────
# Comprobante contable estándar: sirve para programas que importan un layout
# común (o para mapear a mano). Trae TODAS las columnas útiles.
HEADERS_GENERICO = [
    "Tipo comprobante", "Prefijo", "Número", "Fecha", "Cuenta", "Identificación",
    "Detalle", "Débito", "Crédito", "Base", "Centro de costo",
]


def siigo_a_generico(xlsx_siigo: bytes) -> bytes:
    filas = [[m["tipo"], m["prefijo"], m["num"], m["fecha"], m["cuenta"], m["nit"],
              m["detalle"], m["debito"] or None, m["credito"] or None,
              m["base"] or None, m["cc"] or None] for m in _leer_siigo(xlsx_siigo)]
    return _escribir(HEADERS_GENERICO, filas, "Comprobante")


# ── Alegra (BETA — verificar con un archivo de importación real de Alegra) ─────
HEADERS_ALEGRA = [
    "Fecha", "Número", "Cuenta", "Tercero (identificación)", "Débito", "Crédito",
    "Observaciones", "Centro de costo",
]


def siigo_a_alegra(xlsx_siigo: bytes) -> bytes:
    filas = [[m["fecha"], m["num"], m["cuenta"], m["nit"],
              m["debito"] or None, m["credito"] or None, m["detalle"], m["cc"] or None]
             for m in _leer_siigo(xlsx_siigo)]
    return _escribir(HEADERS_ALEGRA, filas, "Comprobantes")


# ── Loggro (BETA — verificar con un archivo de importación real de Loggro) ─────
# Loggro Pymes exige: "Código Encabezado" (un mismo código agrupa las filas de un
# comprobante) y "Moneda" (código funcional, COP en Colombia). La cuenta debe ser
# imputable (auxiliar), no de mayor. Ref.: universidad.loggro.com.
HEADERS_LOGGRO = [
    "Código Encabezado", "Tipo comprobante", "Fecha", "Cuenta", "Moneda",
    "Tercero", "Detalle", "Débito", "Crédito", "Centro de costo",
]


def siigo_a_loggro(xlsx_siigo: bytes) -> bytes:
    # El "Código Encabezado" agrupa las filas de un mismo comprobante: usamos
    # tipo+prefijo+número para que cada comprobante quede con su propio código.
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        enc = "-".join(x for x in (m["tipo"], m["prefijo"], m["num"]) if x) or m["num"]
        filas.append([enc, m["tipo"], m["fecha"], m["cuenta"], "COP",
                      m["nit"], m["detalle"], m["debito"] or None, m["credito"] or None,
                      m["cc"] or None])
    return _escribir(HEADERS_LOGGRO, filas, "Comprobante")


# ── Siigo Pyme (BETA — 4-nov-2026, plantilla «Modelo para la importación de
# movimiento contable - Modelo general» que mandó Lewis Londoño) ───────────────
# Siigo Pyme (el de escritorio, no Siigo Nube) importa con esta plantilla de 145
# columnas: encabezado en la FILA 5 y los movimientos desde la fila 6. Llenamos
# solo lo obligatorio + tercero, descripción, bases y los datos del documento del
# proveedor. El número del comprobante es el MISMO número de la factura (así lo
# lleva el contador); el tipo/código por defecto es P-001 (compras) — confirmar con
# la primera importación de prueba.
HEADERS_SIIGO_PYME = ['TIPO DE COMPROBANTE (OBLIGATORIO)', 'CÓDIGO COMPROBANTE  (OBLIGATORIO)', 'NÚMERO DE DOCUMENTO', 'CUENTA CONTABLE   (OBLIGATORIO)', 'DÉBITO O CRÉDITO (OBLIGATORIO)', 'VALOR DE LA SECUENCIA   (OBLIGATORIO)', 'AÑO DEL DOCUMENTO', 'MES DEL DOCUMENTO', 'DÍA DEL DOCUMENTO', 'CÓDIGO DEL VENDEDOR', 'CÓDIGO DE LA CIUDAD', 'CÓDIGO DE LA ZONA', 'SECUENCIA', 'CENTRO DE COSTO', 'SUBCENTRO DE COSTO', 'NIT', 'SUCURSAL', 'DESCRIPCIÓN DE LA SECUENCIA', 'NÚMERO DE CHEQUE', 'COMPROBANTE ANULADO', 'CÓDIGO DEL MOTIVO DE DEVOLUCIÓN', 'FORMA DE PAGO', 'VALOR DEL CARGO 1 DE LA SECUENCIA', 'VALOR DEL CARGO 2 DE LA SECUENCIA', 'VALOR DEL DESCUENTO 1 DE LA SECUENCIA', 'VALOR DEL DESCUENTO 2 DE LA SECUENCIA', 'VALOR DEL DESCUENTO 3 DE LA SECUENCIA', 'FACTURA ELECTRÓNICA A DEBITAR/ACREDITAR', 'NÚMERO DE FACTURA ELECTRÓNICA A DEBITAR/ACREDITAR', 'PREFIJO DE ORDER REFERENCE', 'CONSECUTIVO DE ORDER REFERENCE', 'PREFIJO ORDEN DE ENTREGA', 'NÚMERO ORDEN DE ENTREGA', 'AÑO FECHA DE ORDEN DE ENTREGA', 'MES FECHA DE ORDEN DE ENTREGA', 'DÍA FECHA DE ORDEN DE ENTREGA', 'INGRESOS PARA TERCEROS', 'FECHA ACTUALIZACIÓN DEL DOCUMENTO', 'HORA DE ACTUALIZACIÓN DEL DOCUMENTO', 'PREFIJO ORDEN DE ENTREGA2', 'NÚMERO ORDEN DE ENTREGA2', 'AÑO FECHA DE ORDEN DE ENTREGA2', 'MES FECHA DE ORDEN DE ENTREGA2', 'DÍA FECHA DE ORDEN DE ENTREGA2', 'PREFIJO ORDEN DE ENTREGA3', 'NÚMERO ORDEN DE ENTREGA3', 'AÑO FECHA DE ORDEN DE ENTREGA3', 'MES FECHA DE ORDEN DE ENTREGA3', 'DÍA FECHA DE ORDEN DE ENTREGA3', 'PREFIJO ORDEN DE ENTREGA4', 'NÚMERO ORDEN DE ENTREGA4', 'AÑO FECHA DE ORDEN DE ENTREGA4', 'MES FECHA DE ORDEN DE ENTREGA4', 'DÍA FECHA DE ORDEN DE ENTREGA4', 'PREFIJO ORDEN DE ENTREGA5', 'NÚMERO ORDEN DE ENTREGA5', 'AÑO FECHA DE ORDEN DE ENTREGA5', 'MES FECHA DE ORDEN DE ENTREGA5', 'DÍA FECHA DE ORDEN DE ENTREGA5', 'PORCENTAJE ALIMENTOS ULTRAPROCESADOS', 'VALOR ALIMENTOS ULTRAPROCESADOS', 'VALOR BEBIDAS AZUCARADAS', 'AÑO EXPEDICIÓN FACTURA', 'MES EXPEDICIÓN FACTURA', 'DÍA EXPEDICIÓN FACTURA', 'RUTA DOCUMENTO', 'CUCON - CÓDIGO ÚNICO DE CONTRATO', 'PORCENTAJE DEL IVA DE LA SECUENCIA', 'VALOR DE IVA DE LA SECUENCIA', 'BASE DE RETENCIÓN', 'BASE PARA CUENTAS MARCADAS COMO RETEIVA', 'SECUENCIA GRAVADA O EXCENTA', 'PORCENTAJE AIU', 'BASE IVA AIU', 'VALOR TOTAL IMPOCONSUMO DE LA SECUENCIA', 'IVA COMO MAYOR VALOR DE LA COMPRA', 'LÍNEA PRODUCTO', 'GRUPO PRODUCTO', 'CÓDIGO PRODUCTO', 'CANTIDAD', 'CANTIDAD DOS', 'CÓDIGO DE LA BODEGA', 'CÓDIGO DE LA UBICACIÓN', 'CANTIDAD DE FACTOR DE CONVERSIÓN', 'OPERADOR DE FACTOR DE CONVERSIÓN', 'VALOR DEL FACTOR DE CONVERSIÓN', 'LOTE', 'AÑO DEL VENCIMIENTO DEL LOTE', 'MES DEL VENCIMIENTO DEL LOTE', 'DÍA DEL VENCIMIENTO DEL LOTE', 'GRUPO ACTIVOS', 'CÓDIGO ACTIVO', 'ADICIÓN O MEJORA', 'VECES ADICIONALES A DEPRECIAR POR ADICIÓN O MEJORA', 'VECES A DEPRECIAR NIIF', 'NÚMERO DEL DOCUMENTO DEL PROVEEDOR', 'PREFIJO DEL DOCUMENTO DEL PROVEEDOR', 'AÑO DOCUMENTO DEL PROVEEDOR', 'MES DOCUMENTO DEL PROVEEDOR', 'DÍA DOCUMENTO DEL PROVEEDOR', 'TIPO DOCUMENTO DE PEDIDO', 'CÓDIGO COMPROBANTE DE PEDIDO', 'NÚMERO DE COMPROBANTE PEDIDO', 'SECUENCIA DE PEDIDO', 'TIPO DE MONEDA ELABORACIÓN', 'TIPO Y COMPROBANTE CRUCE', 'NÚMERO DE DOCUMENTO CRUCE', 'NÚMERO DE VENCIMIENTO', 'AÑO VENCIMIENTO DE DOCUMENTO CRUCE', 'MES VENCIMIENTO DE DOCUMENTO CRUCE', 'DÍA VENCIMIENTO DE DOCUMENTO CRUCE', 'NÚMERO DE CAJA ASOCIADA AL COMPROBANTE', 'CONCEPTO DE NÓMINA', 'CANTIDAD (DÍAS /HORAS. ETC)', 'TIPO DE PAGO', 'DESCRIPCIÓN DE COMENTARIOS', 'DESCRIPCIÓN LARGA', 'INCONTERM', 'DESCRIPCIÓN EXPORTACIÓN', 'MEDIO DE TRANSPORTE', 'PAÍS DE ORIGEN', 'CIUDAD DE ORIGEN', 'PAIS DESTINO', 'CIUDAD DESTINO', 'PESO NETO', 'PESO BRUTO', 'UNIDAD DE MEDIDA NETO', 'UNIDAD DE MEDIDA BRUTO', 'CONCEPTO FACTURACION EN BLOQUE', 'DATOS ESTABLEC. (L=LOCAL O=OFICINA)', 'NÚMERO ESTABLECIMIENTO', '08000-CAMPO LIBRE (08000)', '08001-CAMPO LIBRE (08001)', '08002-CAMPO LIBRE (08002)', '08003-CAMPO LIBRE (08003)', '08004-CAMPO LIBRE (08004)', '08005-OBS1', '08006-OBS 1', '08007-OBS 2', '08050-PEDIDO', '08008-CAMPO LIBRE (08008)', '08009-CAMPO LIBRE (08009)', '08010-CAMPO LIBRE (08010)', '08011-CAMPO LIBRE (08011)', '08020-RECOGIDA']


def _ix_pyme(nombre):
    for i, h in enumerate(HEADERS_SIIGO_PYME):
        if h.upper().startswith(nombre.upper()):
            return i
    raise KeyError(nombre)


def siigo_a_siigo_pyme(xlsx_siigo: bytes, empresa: str = "", tipo: str = "P",
                       codigo: int = 1, tipo_nc: str | None = None,
                       codigo_nc: int | None = None) -> bytes:
    """Re-serializa el plano Siigo (compras, gastos y NC de compras) a la plantilla
    de importación de movimiento contable de Siigo Pyme."""
    import re
    tipo_nc = tipo_nc or tipo
    codigo_nc = codigo if codigo_nc is None else codigo_nc
    ix = {k: _ix_pyme(k) for k in (
        "TIPO DE COMPROBANTE", "CÓDIGO COMPROBANTE", "NÚMERO DE DOCUMENTO", "CUENTA CONTABLE",
        "DÉBITO O CRÉDITO", "VALOR DE LA SECUENCIA", "AÑO DEL DOCUMENTO", "MES DEL DOCUMENTO",
        "DÍA DEL DOCUMENTO", "SECUENCIA", "CENTRO DE COSTO", "NIT", "DESCRIPCIÓN DE LA SECUENCIA",
        "BASE DE RETENCIÓN", "BASE PARA CUENTAS MARCADAS COMO RETEIVA",
        "NÚMERO DEL DOCUMENTO DEL PROVEEDOR", "PREFIJO DEL DOCUMENTO DEL PROVEEDOR",
        "AÑO DOCUMENTO DEL PROVEEDOR", "MES DOCUMENTO DEL PROVEEDOR", "DÍA DOCUMENTO DEL PROVEEDOR")}
    # «SECUENCIA» a secas (no «VALOR DE LA SECUENCIA» ni «DESCRIPCIÓN DE LA SECUENCIA»)
    ix["SECUENCIA"] = HEADERS_SIIGO_PYME.index("SECUENCIA")
    filas, avisos, vistos, secuencia = [], [], {}, {}
    for m in _leer_siigo(xlsx_siigo):
        folio = re.match(r"\s*(?:FC|NC|G)\s*:\s*(.+)$", m["detalle"] or "")
        folio = (folio.group(1) if folio else m["num"] or "").strip().upper()
        pref = re.match(r"^([A-Z]*)", folio).group(1)
        numero = "".join(ch for ch in folio if ch.isdigit()) or "".join(ch for ch in m["num"] if ch.isdigit())
        es_nc = m["grupo"] == "nc"
        t, c = (tipo_nc, codigo_nc) if es_nc else (tipo, codigo)
        clave_doc = (t, c, numero)
        nit = "".join(ch for ch in m["nit"] if ch.isdigit())
        dueño = vistos.setdefault(clave_doc, (m["grupo"], m["num"], nit))
        if dueño != (m["grupo"], m["num"], nit) and clave_doc not in [a[0] for a in avisos]:
            avisos.append((clave_doc, f"{t}-{c:03d} número {numero}: dos documentos distintos "
                                      f"(NIT {dueño[2]} y {nit}) quedarían en el mismo comprobante de Siigo Pyme."))
        secuencia[(m["grupo"], m["num"])] = secuencia.get((m["grupo"], m["num"]), 0) + 1
        f = m["fecha_dt"]
        if f is None:
            try:
                f = datetime.strptime(m["fecha"], "%d/%m/%Y").date()
            except ValueError:
                f = None
        fila = [None] * len(HEADERS_SIIGO_PYME)
        cta = m["cuenta"]
        valor = m["debito"] or m["credito"]
        fila[ix["TIPO DE COMPROBANTE"]] = t
        fila[ix["CÓDIGO COMPROBANTE"]] = int(c)
        fila[ix["NÚMERO DE DOCUMENTO"]] = int(numero) if numero else None
        fila[ix["CUENTA CONTABLE"]] = int(cta) if cta.isdigit() else cta
        fila[ix["DÉBITO O CRÉDITO"]] = "D" if m["debito"] else "C"
        fila[ix["VALOR DE LA SECUENCIA"]] = round(valor, 2)
        if f:
            fila[ix["AÑO DEL DOCUMENTO"]], fila[ix["MES DEL DOCUMENTO"]], fila[ix["DÍA DEL DOCUMENTO"]] = f.year, f.month, f.day
            fila[ix["AÑO DOCUMENTO DEL PROVEEDOR"]], fila[ix["MES DOCUMENTO DEL PROVEEDOR"]], fila[ix["DÍA DOCUMENTO DEL PROVEEDOR"]] = f.year, f.month, f.day
        fila[ix["SECUENCIA"]] = secuencia[(m["grupo"], m["num"])]
        if m["cc"] and m["cc"].isdigit():
            fila[ix["CENTRO DE COSTO"]] = int(m["cc"])
        fila[ix["NIT"]] = int(nit) if nit else None
        fila[ix["DESCRIPCIÓN DE LA SECUENCIA"]] = (m["detalle"] or "")[:50]
        if m["base"]:
            if cta.startswith("2367"):
                fila[ix["BASE PARA CUENTAS MARCADAS COMO RETEIVA"]] = m["base"]
            else:
                fila[ix["BASE DE RETENCIÓN"]] = m["base"]
        fila[ix["NÚMERO DEL DOCUMENTO DEL PROVEEDOR"]] = int(numero) if numero else None
        fila[ix["PREFIJO DEL DOCUMENTO DEL PROVEEDOR"]] = pref or None
        filas.append(fila)

    # agrupadas por comprobante (tipo, código, número) y en orden de secuencia
    k = (ix["TIPO DE COMPROBANTE"], ix["CÓDIGO COMPROBANTE"], ix["NÚMERO DE DOCUMENTO"], ix["SECUENCIA"])
    filas.sort(key=lambda f: tuple((f[i] if f[i] is not None else 0) if j else str(f[i] or "")
                                   for j, i in enumerate(k)))
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Hoja1"
    ws.cell(row=1, column=1, value=(empresa or "").upper() or None)
    ws.cell(row=2, column=1, value="MODELO PARA LA IMPORTACION DE MOVIMIENTO CONTABLE - MODELO GENERAL")
    for c, h in enumerate(HEADERS_SIIGO_PYME, 1):
        cell = ws.cell(row=5, column=c, value=h)
        cell.font = Font(bold=True)
    for r, fila in enumerate(filas, 6):
        for c, val in enumerate(fila, 1):
            if val is not None:
                ws.cell(row=r, column=c, value=val)
    ws.column_dimensions["B"].width = 12
    for r in range(6, 6 + len(filas)):
        ws.cell(row=r, column=2).number_format = "000"
    if avisos:
        wa = wb.create_sheet("AVISOS")
        wa.cell(row=1, column=1, value="Revisar antes de importar")
        for i, (_, txt) in enumerate(avisos, 2):
            wa.cell(row=i, column=1, value=txt)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()
