"""Planos para otros programas contables (World Office, Helisa, Genérico, Alegra, Loggro).

El plano Siigo es el intermedio canónico: cada fila ya es un movimiento de
doble partida (cuenta, tercero, débito/crédito, base) con las reglas de cuentas
y retenciones del cliente aplicadas. Aquí solo lo RE-SERIALIZAMOS al formato de
importación de cada programa, sin recalcular nada — así el asiento es idéntico
al de Siigo/Contai y solo cambian las columnas del archivo.

Ambos importadores (World Office «Importar contabilidad» y Helisa «Importar
comprobantes») permiten mapear columnas al importar, así que el orden aquí sigue
el layout estándar y se puede ajustar a la plantilla exacta de cada versión.
"""
from __future__ import annotations

import io
from datetime import datetime, date

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

_BORDE = Border(*(Side(style="thin", color="BFCCD8"),) * 4)


def _num(v) -> float:
    try:
        return round(float(v), 2)
    except (TypeError, ValueError):
        return 0.0


def _fmt_fecha(v) -> str:
    """Fecha en dd/MM/yyyy (formato que aceptan World Office y Helisa)."""
    if isinstance(v, (datetime, date)):
        return v.strftime("%d/%m/%Y")
    s = str(v or "").strip()
    if not s:
        return ""
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
                "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s[:len(fmt) + 2], fmt).strftime("%d/%m/%Y")
        except ValueError:
            continue
    return s


# Hoja del plano Siigo → grupo de comprobante. Las ventas del convertidor salen
# consolidadas por cliente y con las cuentas por defecto de Siigo (13050501,
# 41009501, 24080501), no con las del cliente: por eso los demás programas solo
# re-serializan compras, gastos y notas crédito de compras.
GRUPO_HOJA = {"COMPRAS": "compras", "NC COMPRAS": "nc", "GASTOS": "gastos",
              "VENTAS": "ventas", "NC VENTAS": "nc_ventas"}
HOJAS_COMPRAS = ("COMPRAS", "NC COMPRAS", "GASTOS")


def _leer_siigo(xlsx_bytes: bytes, hojas=HOJAS_COMPRAS) -> list[dict]:
    """Lee el plano Siigo (.xlsx) y devuelve la lista de movimientos.

    Recorre TODAS las hojas de movimiento (COMPRAS, NC COMPRAS, GASTOS…), no solo
    la activa: antes solo se leía la primera y las demás se perdían en silencio.
    `hojas`: nombres de hoja a incluir (None = todas las que tengan movimientos;
    un plano de una sola hoja sin nombre de grupo también se lee completo).
    Localiza las columnas por nombre (tolerante a tildes/orden), igual que
    helisa_api.asiento_desde_plano_siigo, para no romperse si cambia el layout.
    """
    wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), read_only=True, data_only=True)
    permitidas = {h.upper() for h in hojas} if hojas else None
    movs = []
    for nombre_hoja in wb.sheetnames:
        grupo = GRUPO_HOJA.get(nombre_hoja.strip().upper())
        if permitidas is not None and grupo is not None and nombre_hoja.strip().upper() not in permitidas:
            continue
        filas = list(wb[nombre_hoja].iter_rows(values_only=True))
        if not filas or str(filas[0][0] or "").strip().lower() != "tipo de comprobante":
            continue
        movs.extend(_movs_de_hoja(filas, grupo))
    return movs


def _movs_de_hoja(filas, grupo) -> list[dict]:
    cab = [str(c or "").strip().lower() for c in filas[0]]

    def col(*nombres):
        for n in nombres:
            for i, c in enumerate(cab):
                if n in c:
                    return i
        return None

    c_tipo = col("tipo de comprobante")
    c_num = col("consecutivo comprobante")
    c_fec = col("fecha de elaboración", "fecha de elaboracion")
    c_cta = col("código cuenta", "codigo cuenta")
    c_ter = col("identificación tercero", "identificacion tercero")
    c_pref = col("prefijo")
    c_imp = col("código impuesto", "codigo impuesto")
    c_des = col("descripción", "descripcion")
    c_cc = col("centro/subcentro", "centro de costos")
    c_deb = col("débito", "debito")
    c_cre = col("crédito", "credito")
    c_base = col("base gravable")

    def g(row, idx):
        return row[idx] if idx is not None and idx < len(row) else None

    movs = []
    for row in filas[1:]:
        if c_cta is None:
            break
        cuenta = str(g(row, c_cta) or "").strip()
        if not cuenta:
            continue
        deb = _num(g(row, c_deb))
        cre = _num(g(row, c_cre))
        if not deb and not cre:
            continue
        nit = g(row, c_ter)
        fecha = g(row, c_fec)
        movs.append({
            "grupo": grupo,
            "tipo": str(g(row, c_tipo) or "").strip(),
            "num": str(g(row, c_num) or "").strip(),
            "prefijo": str(g(row, c_pref) or "").strip(),
            "fecha": _fmt_fecha(fecha),
            "fecha_dt": fecha.date() if isinstance(fecha, datetime) else (fecha if isinstance(fecha, date) else None),
            "cuenta": cuenta,
            "nit": str(nit).strip() if nit else "",
            "cod_imp": g(row, c_imp),
            "detalle": str(g(row, c_des) or "").strip(),
            "cc": str(g(row, c_cc) or "").strip(),
            "debito": deb,
            "credito": cre,
            "base": _num(g(row, c_base)),
        })
    return movs


def _escribir(headers, filas, hoja: str) -> bytes:
    """Arma un .xlsx con encabezados con estilo y las filas de movimiento."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = hoja
    fill = PatternFill(fill_type="solid", fgColor="1a3a5c")
    font = Font(bold=True, color="FFFFFF", name="Calibri", size=10)
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _BORDE
    ws.row_dimensions[1].height = 22
    for r, fila in enumerate(filas, 2):
        for c, val in enumerate(fila, 1):
            cell = ws.cell(row=r, column=c, value=val)
            cell.border = _BORDE
            if isinstance(val, (int, float)):
                cell.number_format = "#,##0.00"
    # anchos aproximados
    for c, h in enumerate(headers, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = max(11, min(30, len(h) + 3))
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ── World Office ──────────────────────────────────────────────────────────────
HEADERS_WO = [
    "Tipo de comprobante", "Prefijo", "Número", "Fecha", "Cuenta contable",
    "Identificación tercero", "Concepto", "Débito", "Crédito",
    "Base", "Centro de costo",
]


def siigo_a_worldoffice(xlsx_siigo: bytes) -> bytes:
    """Convierte el plano Siigo al Excel de importación de World Office.

    Cada fila es una línea del comprobante contable; World Office agrupa por
    (Tipo + Prefijo + Número) al importar.
    """
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        filas.append([
            m["tipo"], m["prefijo"], m["num"], m["fecha"], m["cuenta"],
            m["nit"], m["detalle"],
            m["debito"] or None, m["credito"] or None,
            m["base"] or None, m["cc"] or None,
        ])
    return _escribir(HEADERS_WO, filas, "Contabilidad")


# ── Helisa ────────────────────────────────────────────────────────────────────
HEADERS_HELISA = [
    "Comprobante", "Número", "Fecha", "Cuenta", "Nit", "Detalle",
    "Débito", "Crédito", "Base", "Centro de costo",
]


def siigo_a_helisa(xlsx_siigo: bytes) -> bytes:
    """Convierte el plano Siigo al Excel de importación de comprobantes de Helisa."""
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        filas.append([
            m["tipo"], m["num"], m["fecha"], m["cuenta"], m["nit"], m["detalle"],
            m["debito"] or None, m["credito"] or None,
            m["base"] or None, m["cc"] or None,
        ])
    return _escribir(HEADERS_HELISA, filas, "Comprobantes")


# ── Genérico / estándar ───────────────────────────────────────────────────────
# Comprobante contable estándar: sirve para programas que importan un layout
# común (o para mapear a mano). Trae TODAS las columnas útiles.
HEADERS_GENERICO = [
    "Tipo comprobante", "Prefijo", "Número", "Fecha", "Cuenta", "Identificación",
    "Detalle", "Débito", "Crédito", "Base", "Centro de costo",
]


def siigo_a_generico(xlsx_siigo: bytes) -> bytes:
    filas = [[m["tipo"], m["prefijo"], m["num"], m["fecha"], m["cuenta"], m["nit"],
              m["detalle"], m["debito"] or None, m["credito"] or None,
              m["base"] or None, m["cc"] or None] for m in _leer_siigo(xlsx_siigo)]
    return _escribir(HEADERS_GENERICO, filas, "Comprobante")


# ── Alegra (BETA — verificar con un archivo de importación real de Alegra) ─────
HEADERS_ALEGRA = [
    "Fecha", "Número", "Cuenta", "Tercero (identificación)", "Débito", "Crédito",
    "Observaciones", "Centro de costo",
]


def siigo_a_alegra(xlsx_siigo: bytes) -> bytes:
    filas = [[m["fecha"], m["num"], m["cuenta"], m["nit"],
              m["debito"] or None, m["credito"] or None, m["detalle"], m["cc"] or None]
             for m in _leer_siigo(xlsx_siigo)]
    return _escribir(HEADERS_ALEGRA, filas, "Comprobantes")


# ── Loggro (BETA — verificar con un archivo de importación real de Loggro) ─────
# Loggro Pymes exige: "Código Encabezado" (un mismo código agrupa las filas de un
# comprobante) y "Moneda" (código funcional, COP en Colombia). La cuenta debe ser
# imputable (auxiliar), no de mayor. Ref.: universidad.loggro.com.
HEADERS_LOGGRO = [
    "Código Encabezado", "Tipo comprobante", "Fecha", "Cuenta", "Moneda",
    "Tercero", "Detalle", "Débito", "Crédito", "Centro de costo",
]


def siigo_a_loggro(xlsx_siigo: bytes) -> bytes:
    # El "Código Encabezado" agrupa las filas de un mismo comprobante: usamos
    # tipo+prefijo+número para que cada comprobante quede con su propio código.
    filas = []
    for m in _leer_siigo(xlsx_siigo):
        enc = "-".join(x for x in (m["tipo"], m["prefijo"], m["num"]) if x) or m["num"]
        filas.append([enc, m["tipo"], m["fecha"], m["cuenta"], "COP",
                      m["nit"], m["detalle"], m["debito"] or None, m["credito"] or None,
                      m["cc"] or None])
    return _escribir(HEADERS_LOGGRO, filas, "Comprobante")
