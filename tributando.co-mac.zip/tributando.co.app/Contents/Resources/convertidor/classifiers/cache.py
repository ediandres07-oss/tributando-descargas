"""
Caché SQLite de clasificaciones IA previas: misma empresa + NIT + descripción
normalizada -> mismo resultado, sin volver a llamar la API.
"""

import os
import tempfile
import threading

try:
    import sqlite3
except Exception:              # algunos empaquetados no traen sqlite3
    sqlite3 = None


def _ruta_db_escribible():
    """Ruta de la caché en una carpeta ESCRIBIBLE. Dentro del .exe la carpeta del
    programa es de solo lectura (da 'unable to open database file'), así que se
    usa la carpeta de datos del usuario (%APPDATA%\\LectorXML en Windows)."""
    try:
        from rutas import DATA_DIR          # %APPDATA%\LectorXML / ~/Library/...
        base = DATA_DIR
    except Exception:
        base = os.path.join(os.path.expanduser("~"), ".lectorxml")
    try:
        os.makedirs(base, exist_ok=True)
        return os.path.join(base, "cache_clasificacion.sqlite3")
    except Exception:
        return os.path.join(tempfile.gettempdir(), "cache_clasificacion.sqlite3")


_RUTA_DB = _ruta_db_escribible()
_lock = threading.Lock()


class CacheClasificacion:
    def __init__(self, ruta_db=None):
        self.ruta_db = ruta_db or _RUTA_DB
        self.activo = sqlite3 is not None
        if self.activo:
            try:
                self._crear_tabla()
            except Exception:
                # Si la BD no se puede abrir/crear, seguimos SIN caché en vez de
                # romper la generación del plano.
                self.activo = False

    def _conectar(self):
        return sqlite3.connect(self.ruta_db)

    def _crear_tabla(self):
        with _lock, self._conectar() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    empresa_nit TEXT NOT NULL,
                    nit TEXT NOT NULL,
                    descripcion TEXT NOT NULL,
                    cuenta TEXT,
                    tipo TEXT,
                    naturaleza TEXT,
                    confianza REAL,
                    justificacion TEXT,
                    PRIMARY KEY (empresa_nit, nit, descripcion)
                )
            """)

    def get(self, empresa_nit, nit, descripcion):
        if not self.activo:
            return None
        try:
            with _lock, self._conectar() as con:
                cur = con.execute(
                    "SELECT cuenta, tipo, naturaleza, confianza, justificacion "
                    "FROM cache WHERE empresa_nit=? AND nit=? AND descripcion=?",
                    (empresa_nit, str(nit).strip(), descripcion)
                )
                row = cur.fetchone()
        except Exception:
            return None
        if not row:
            return None
        cuenta, tipo, naturaleza, confianza, justificacion = row
        return {
            'cuenta': cuenta, 'tipo': tipo, 'naturaleza': naturaleza,
            'confianza': confianza, 'justificacion': justificacion
        }

    def set(self, empresa_nit, nit, descripcion, resultado):
        if not self.activo:
            return
        try:
            with _lock, self._conectar() as con:
                con.execute(
                    "INSERT OR REPLACE INTO cache "
                    "(empresa_nit, nit, descripcion, cuenta, tipo, naturaleza, confianza, justificacion) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (empresa_nit, str(nit).strip(), descripcion,
                     resultado.get('cuenta'), resultado.get('tipo'),
                     resultado.get('naturaleza'), resultado.get('confianza'),
                     resultado.get('justificacion'))
                )
        except Exception:
            pass
