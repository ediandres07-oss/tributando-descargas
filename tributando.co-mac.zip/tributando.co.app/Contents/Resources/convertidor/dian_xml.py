"""
Lector de XMLs de facturación electrónica DIAN (UBL 2.1).

Acepta un ZIP con XMLs (como se descargan del portal DIAN o llegan al
correo de facturación) o un XML individual. Soporta:
  - Invoice (factura electrónica) y CreditNote (nota crédito)
  - AttachedDocument (el sobre que envuelve la factura en CDATA)
  - ZIPs anidados (cada factura suele venir en su propio .zip)
Ignora ApplicationResponse (eventos) y NominaIndividual.

A diferencia del Excel resumen de la DIAN (solo IVA y Total por
documento), el XML trae la base gravada REAL y las retenciones
declaradas, así que no hay que inferir tarifas.

Entrega los documentos con la misma forma que converter._leer_todo para
que los planos Siigo/Contai y la liquidación de IVA funcionen sin
cambios. El campo extra 'base_gravada' (base IVA real del XML) lo usa la
liquidación de IVA para bases exactas; 'gravado' conserva la semántica
total-IVA que los planos usan para cuadrar débito=crédito.
"""

import io
import re
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime


def _sin_ns(tag):
    """Nombre local del tag (sin namespace)."""
    return tag.rsplit('}', 1)[-1]


def _parsear_sin_ns(xml_bytes):
    """Parsea XML y reescribe todos los tags a su nombre local, para
    buscar sin pelear con los namespaces UBL (que cambian por tipo doc)."""
    root = ET.fromstring(xml_bytes)
    for el in root.iter():
        el.tag = _sin_ns(el.tag)
    return root


def _texto(el, ruta):
    n = el.find(ruta)
    return (n.text or '').strip() if n is not None and n.text else ''


def _num(el, ruta):
    t = _texto(el, ruta)
    try:
        return float(t)
    except ValueError:
        return 0.0


def _solo_digitos(v):
    return re.sub(r'\D', '', v or '')


def _extraer_documento(root):
    """Extrae un dict de un Invoice/CreditNote ya parseado (sin ns)."""
    tipo_root = root.tag
    if tipo_root == 'AttachedDocument':
        # La factura real viene embebida en CDATA dentro del sobre
        cdata = _texto(root, './/Attachment/ExternalReference/Description')
        if not cdata:
            return None
        try:
            return _extraer_documento(_parsear_sin_ns(cdata.encode('utf-8')))
        except ET.ParseError:
            return None
    if tipo_root not in ('Invoice', 'CreditNote', 'DebitNote'):
        return None  # ApplicationResponse, NominaIndividual, etc.

    folio = _texto(root, 'ID')
    cufe = _texto(root, 'UUID')
    fecha_txt = _texto(root, 'IssueDate')
    try:
        fecha = datetime.strptime(fecha_txt, '%Y-%m-%d')
    except ValueError:
        fecha = None

    nit_emisor = _solo_digitos(_texto(
        root, './/AccountingSupplierParty/Party/PartyTaxScheme/CompanyID'))
    nombre_emisor = _texto(
        root, './/AccountingSupplierParty/Party/PartyTaxScheme/RegistrationName')
    nit_receptor = _solo_digitos(_texto(
        root, './/AccountingCustomerParty/Party/PartyTaxScheme/CompanyID'))
    nombre_receptor = _texto(
        root, './/AccountingCustomerParty/Party/PartyTaxScheme/RegistrationName')

    total = _num(root, './/LegalMonetaryTotal/PayableAmount')

    # IVA (TaxScheme ID '01') a nivel documento: base gravada real + IVA.
    # Otros esquemas (04 INC, 22 bolsas, etc.) no son IVA descontable.
    base_iva = 0.0
    iva = 0.0
    inc = 0.0                      # 04 = consumo, 22 = bolsas plásticas
    for tt in root.findall('TaxTotal'):
        for sub in tt.findall('TaxSubtotal'):
            esquema = _texto(sub, './/TaxCategory/TaxScheme/ID')
            if esquema == '01':
                base_iva += _num(sub, 'TaxableAmount')
                iva += _num(sub, 'TaxAmount')
            elif esquema in ('04', '22'):
                inc += _num(sub, 'TaxAmount')

    # Retenciones declaradas (05 reteIVA, 06 retefuente, 07 reteICA)
    ret = {'05': 0.0, '06': 0.0, '07': 0.0}
    for wt in root.findall('WithholdingTaxTotal'):
        for sub in wt.findall('TaxSubtotal'):
            esquema = _texto(sub, './/TaxCategory/TaxScheme/ID')
            if esquema in ret:
                ret[esquema] += _num(sub, 'TaxAmount')

    tipo = ('nota de crédito electrónica' if tipo_root == 'CreditNote'
            else 'factura electrónica')

    return {
        'tipo': tipo, 'folio': folio, 'cufe': cufe, 'fecha': fecha,
        'nit_emisor': nit_emisor, 'nombre_emisor': nombre_emisor,
        'nit_receptor': nit_receptor, 'nombre_receptor': nombre_receptor,
        'total': round(total, 2), 'iva': round(iva, 2),
        'base_gravada': round(base_iva, 2), 'inc': round(inc, 2),
        'reteiva': round(ret['05'], 2), 'retefuente': round(ret['06'], 2),
        'reteica': round(ret['07'], 2),
    }


def _iterar_xmls(data):
    """Genera bytes de cada XML dentro de data (zip, zip anidado o xml)."""
    if data[:2] == b'PK':
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                for nombre in zf.namelist():
                    low = nombre.lower()
                    if low.endswith('/'):
                        continue
                    contenido = zf.read(nombre)
                    if low.endswith('.xml'):
                        yield contenido
                    elif low.endswith('.zip'):
                        yield from _iterar_xmls(contenido)  # zip anidado
        except zipfile.BadZipFile:
            return
    elif data.lstrip()[:1] == b'<':
        yield data


def es_archivo_xml_dian(data):
    """True si data es un XML o un ZIP de XMLs (y NO un .xlsx, que
    también es un ZIP pero contiene [Content_Types].xml)."""
    if data.lstrip()[:1] == b'<':
        return True
    if data[:2] != b'PK':
        return False
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            nombres = [n.lower() for n in zf.namelist()]
    except zipfile.BadZipFile:
        return False
    if '[content_types].xml' in nombres:  # es un Excel .xlsx
        return False
    return any(n.endswith('.xml') or n.endswith('.zip') for n in nombres)


def leer_todo_xml(data, mi_nit=None):
    """Lee ZIP/XML DIAN y retorna la misma tupla que converter._leer_todo:
    (mi_nit, facturas_compras, facturas_gastos, notas_credito,
     ventas, nc_ventas, base_ventas, iva_ventas, base_nc_ventas,
     iva_nc_ventas, fecha_ini, fecha_fin)

    mi_nit: si se pasa, se usa como NIT del negocio en vez de autodetectarlo
    (útil en buzones de bajo volumen donde emisor y receptor empatan).
    """
    from converter import (NIT_PROVEEDOR_INVENTARIO,  # evitar import circular
                           cargar_reglas_siigo)

    docs = []
    vistos = set()  # dedup por CUFE (el mismo XML puede venir 2 veces)
    for xml_bytes in _iterar_xmls(data):
        try:
            root = _parsear_sin_ns(xml_bytes)
        except ET.ParseError:
            continue
        d = _extraer_documento(root)
        if d is None or not d['folio']:
            continue
        clave = d['cufe'] or f"{d['nit_emisor']}|{d['folio']}|{d['tipo']}"
        if clave in vistos:
            continue
        vistos.add(clave)
        docs.append(d)

    if not docs:
        raise ValueError(
            'El archivo no contiene XMLs de facturas DIAN legibles '
            '(Invoice/CreditNote/AttachedDocument).')

    # mi_nit: el NIT que más aparece entre emisor y receptor (salvo que se
    # pase explícito, p. ej. desde el buzón de un cliente ya identificado).
    if not mi_nit:
        conteo = Counter()
        for d in docs:
            for n in (d['nit_emisor'], d['nit_receptor']):
                if n and len(n) >= 6:
                    conteo[n] += 1
        mi_nit = conteo.most_common(1)[0][0]
    mi_nit = str(mi_nit)

    # Proveedores cuyas facturas van a COMPRAS (inventario). Cada empresa
    # los declara en reglas_siigo/<nit>.json -> "nits_compras"; si no, se
    # usa el proveedor de inventario histórico (compatibilidad).
    _reglas = cargar_reglas_siigo(mi_nit)
    nits_compras = {str(n) for n in (_reglas.get('nits_compras') or [])} \
        if _reglas else set()
    if not nits_compras:
        nits_compras = {NIT_PROVEEDOR_INVENTARIO}

    facturas_compras = []; facturas_gastos = []; notas_credito = []
    ventas = []; nc_ventas = []
    base_ventas = iva_ventas = base_nc_ventas = iva_nc_ventas = 0.0
    fechas = []

    for d in docs:
        es_nc = 'nota de cr' in d['tipo']
        iva_r = round(d['iva'], 2)
        total_r = round(d['total'], 2)
        base_r = round(total_r - iva_r, 2)   # semántica de los planos
        # base real del XML acotada a lo que cabe en el documento
        base_gravada = min(round(d['base_gravada'], 2), base_r)

        es_recibido = (d['nit_receptor'] == mi_nit and d['nit_emisor'] != mi_nit)
        es_emitido = (d['nit_emisor'] == mi_nit)

        if es_recibido:
            doc = {'folio': d['folio'], 'fecha': d['fecha'], 'nit': d['nit_emisor'],
                   'nombre': d['nombre_emisor'],
                   'no_gravado': 0.0, 'gravado': base_r, 'iva': iva_r,
                   'total': total_r, 'base_gravada': base_gravada,
                   'inc': round(d.get('inc', 0.0), 2),
                   'retefuente': d['retefuente'], 'reteiva': d['reteiva']}
            if es_nc:
                notas_credito.append(doc)
            elif d['nit_emisor'] in nits_compras:
                facturas_compras.append(doc)
            else:
                facturas_gastos.append(doc)

        if es_emitido:
            vdoc = {'folio': d['folio'], 'fecha': d['fecha'], 'nit': d['nit_receptor'],
                    'nombre': d['nombre_receptor'], 'gravado': base_r,
                    'iva': iva_r, 'total': total_r, 'base_gravada': base_gravada,
                    'retefuente': d['retefuente'], 'reteiva': d['reteiva']}
            if es_nc:
                nc_ventas.append(vdoc)
                base_nc_ventas += base_r; iva_nc_ventas += iva_r
            else:
                ventas.append(vdoc)
                base_ventas += base_r; iva_ventas += iva_r
            if d['fecha']:
                fechas.append(d['fecha'])

    fecha_ini = min(fechas) if fechas else None
    fecha_fin = max(fechas) if fechas else None

    return (mi_nit,
            facturas_compras, facturas_gastos, notas_credito,
            ventas, nc_ventas,
            base_ventas, iva_ventas, base_nc_ventas, iva_nc_ventas,
            fecha_ini, fecha_fin)
