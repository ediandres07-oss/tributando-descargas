@echo off
title Descargador Tributando
cd /d "%~dp0"
echo  Preparando, un momento...
REM Quitar la marca "archivo de internet" que bloquea la ejecucion
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -File | Unblock-File" >nul 2>&1
REM Buscar Google Chrome
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME (
  echo  Necesitas Google Chrome instalado:  https://www.google.com/chrome
  pause & exit /b 1
)
REM Abrir Chrome automaticamente cuando el servidor responda
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 60;$i++){try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',5077);$c.Close();Start-Process '%CHROME%' 'http://127.0.0.1:5077';break}catch{Start-Sleep -Milliseconds 700}}"
echo  Iniciando el Descargador Tributando...
echo  (NO cierres esta ventana mientras lo uses)
echo(
"runtime\python.exe" app.py
echo(
echo  El programa se detuvo. Puedes cerrar esta ventana.
pause
