@echo off
REM Motor interno (lo lanza el .vbs OCULTO: sin ventana negra).
REM Arranca el servidor sin consola (pythonw), espera a que levante y abre Chrome.
cd /d "%~dp0"

REM --- Crear el icono (con logo) en el Escritorio la 1a vez ---
if not exist "%USERPROFILE%\Desktop\Descargador Tributando.lnk" call "%~dp0_icono.bat"

REM --- Buscar Google Chrome ---
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME (
  msg "%USERNAME%" Necesitas Google Chrome instalado: https://www.google.com/chrome
  exit /b 1
)

REM --- Arrancar el servidor SIN consola (pythonw) y log a archivo para diagnostico ---
start "" /b "runtime\pythonw.exe" app.py > "%TEMP%\descargador_tributando.log" 2>&1

REM --- Esperar a que el puerto 5077 responda y abrir Chrome ---
powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 40;$i++){try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',5077);$c.Close();Start-Process -FilePath '%CHROME%' -ArgumentList 'http://127.0.0.1:5077';break}catch{Start-Sleep -Milliseconds 700}}"
