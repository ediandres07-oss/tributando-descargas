"""Descarga de XML desde la DIAN manejando un navegador real (Playwright).

Por qué un navegador real: el portal `catalogo-vpfe.dian.gov.co` protege CADA
descarga con un captcha Cloudflare Turnstile. En un navegador de verdad el
Turnstile (widget flotante, pasivo) se aprueba solo y emite un token; nosotros
lo leemos y lo usamos para bajar el archivo. NO se falsifica ni se resuelve el
captcha con servicios externos: si el Turnstile alguna vez lo desafía de forma
interactiva, el usuario lo resuelve en la ventana (por eso corre visible).

Flujo tipo Contalink:
  1. activar(token_url)  → abre sesión con el enlace del correo DIAN.
     El indicador va de "activando" a "activo" (verde) cuando la sesión quedó
     lista y el Turnstile ya emitió su primer token.
  2. descargar(cufe)     → por cada CUFE, refresca el token y baja el ZIP,
     del que extrae el/los XML.

Playwright (API síncrona) es sensible al hilo: toda la interacción con el
navegador vive en UN worker thread; la app le habla por una cola.
"""
from __future__ import annotations

import os
import queue
import threading
import time
import zipfile
import io

from rutas import DATA_DIR
import zip_utils

PORTAL = "https://catalogo-vpfe.dian.gov.co"
CERT_PORTAL = "https://certificate-vpfe.dian.gov.co"
PERFIL = os.path.join(DATA_DIR, ".perfil_chrome")
# Copia de ZIPs protegidos que no se pudieron abrir, para diagnóstico.
DEBUG_CIFRADO = os.path.join(DATA_DIR, "zip_protegidos")


class DianSession:
    """Maneja un navegador real en un hilo dedicado. Thread-safe vía cola."""

    def __init__(self):
        self._cmd: queue.Queue = queue.Queue()
        self._hilo = threading.Thread(target=self._worker, daemon=True)
        self._estado = {"estado": "inactivo", "empresa": "", "mensaje": ""}
        self._lock = threading.Lock()
        self._hilo.start()

    # ---------- API pública (llamada desde Flask) ----------

    def estado(self) -> dict:
        with self._lock:
            return dict(self._estado)

    def _set(self, **kw):
        with self._lock:
            self._estado.update(kw)

    def activar(self, token_url: str, timeout: float = 420) -> dict:
        return self._ejecutar(("activar", token_url), timeout=timeout)

    def activar_certificado(self, p12_path: str, passphrase: str, timeout: float = 360) -> dict:
        return self._ejecutar(("activar_cert", (p12_path, passphrase)), timeout=timeout)

    def descargar(self, cufe: str, passwords=(), timeout: float = 180) -> dict:
        return self._ejecutar(("descargar", (cufe.strip(), tuple(passwords))),
                              timeout=timeout)

    def listar(self, fecha_inicio: str, fecha_fin: str, tipo: str = "recibidos",
               timeout: float = 600) -> dict:
        return self._ejecutar(("listar", (fecha_inicio, fecha_fin, tipo)), timeout=timeout)

    def cerrar(self):
        try:
            self._ejecutar(("cerrar", None), timeout=15)
        except Exception:
            pass

    def _ejecutar(self, cmd, timeout: float) -> dict:
        resp: queue.Queue = queue.Queue(maxsize=1)
        self._cmd.put((cmd, resp))
        try:
            return resp.get(timeout=timeout)
        except queue.Empty:
            return {"ok": False, "error": "Tiempo de espera agotado"}

    # ---------- Worker (único dueño del navegador) ----------

    def _worker(self):
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        self._ctx = None
        self._page = None
        self._browser = None   # solo en modo nube (Scraping Browser remoto)
        while True:
            (accion, arg), resp = self._cmd.get()
            try:
                if accion == "activar":
                    resp.put(self._do_activar(arg))
                elif accion == "activar_cert":
                    resp.put(self._do_activar_certificado(*arg))
                elif accion == "descargar":
                    resp.put(self._do_descargar(*arg))
                elif accion == "listar":
                    resp.put(self._do_listar(*arg))
                elif accion == "cerrar":
                    self._do_cerrar()
                    resp.put({"ok": True})
            except Exception as e:
                self._set(estado="error", mensaje=str(e)[:200])
                resp.put({"ok": False, "error": str(e)[:200]})

    def _vivo(self) -> bool:
        """¿El navegador sigue abierto y usable? Prueba ACTIVA, no solo consulta."""
        if self._ctx is None or self._page is None:
            return False
        try:
            self._page.evaluate("1")   # si el navegador murió, esto lanza excepción
            return True
        except Exception:
            # La pestaña murió; ¿queda otra viva en el contexto?
            try:
                for p in self._ctx.pages:
                    p.evaluate("1")
                    self._page = p
                    return True
            except Exception:
                pass
            return False

    def _relanzar(self, client_certificates=None):
        """Cierra lo que haya y abre un navegador nuevo y limpio."""
        try:
            if self._ctx is not None:
                self._ctx.close()
        except Exception:
            pass
        self._ctx = None
        self._page = None
        self._lanzar(client_certificates)

    def _lanzar(self, client_certificates=None):
        if self._ctx is not None:
            if self._vivo():
                return
            # Navegador muerto (el usuario cerró la ventana): descartar y relanzar.
            try:
                self._ctx.close()
            except Exception:
                pass
            self._ctx = None
            self._page = None
        # --- MODO NUBE: navegador remoto (Bright Data Scraping Browser) ---
        # Si SCRAPING_BROWSER_WSS está seteado, NO abrimos Chrome local: nos
        # conectamos al navegador en la nube del proveedor, que ya trae proxies
        # residenciales + anti-Cloudflare (pasa el bloqueo de la DIAN). El resto
        # del flujo (activar/listar/descargar) no cambia. El certificado .p12 no
        # aplica en este modo (solo el flujo por token del correo).
        wss = os.environ.get("SCRAPING_BROWSER_WSS", "").strip()
        if wss:
            self._browser = self._pw.chromium.connect_over_cdp(wss, timeout=120000)
            self._ctx = (self._browser.contexts[0] if self._browser.contexts
                         else self._browser.new_context(
                             viewport={"width": 1280, "height": 860},
                             accept_downloads=True))
            self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
            return

        # --- MODO LOCAL: Chrome en la máquina del cliente ---
        os.makedirs(PERFIL, exist_ok=True)
        # HEADLESS=1 → corre sin ventana. Por defecto visible (el usuario ve el
        # captcha si lo desafía).
        _headless = os.environ.get("HEADLESS", "0").strip() in ("1", "true", "si")
        kw = dict(
            user_data_dir=PERFIL,
            headless=_headless,
            viewport={"width": 1280, "height": 860},
            accept_downloads=True,
            args=["--disable-blink-features=AutomationControlled"],
        )
        if client_certificates:
            kw["client_certificates"] = client_certificates
        # Chrome con su sandbox normal: sin esto Playwright lo abre con
        # --no-sandbox y Chrome le muestra al contador la barra amarilla «No se
        # admite el indicador de línea de comandos (--no-sandbox)…».
        try:
            # En el servidor no hay Chrome del sistema → cae a Chromium (el except).
            self._ctx = self._pw.chromium.launch_persistent_context(
                channel="chrome", chromium_sandbox=True, **kw)
        except Exception:
            try:
                self._ctx = self._pw.chromium.launch_persistent_context(channel="chrome", **kw)
            except Exception:
                self._ctx = self._pw.chromium.launch_persistent_context(**kw)
        self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()

    def _do_activar_certificado(self, p12_path: str, passphrase: str) -> dict:
        if not p12_path or not os.path.isfile(p12_path):
            return {"ok": False, "error": f"No encuentro el certificado: {p12_path}"}
        self._set(estado="activando", mensaje="Cargando certificado…")

        # El dominio de certificado exige el .p12 en el propio handshake TLS (mTLS).
        certs = [{
            "origin": CERT_PORTAL,
            "pfxPath": p12_path,
            "passphrase": passphrase or "",
        }]
        # Hay que (re)lanzar el navegador CON el certificado en el contexto.
        self._do_cerrar()
        try:
            self._lanzar(client_certificates=certs)
        except Exception as e:
            self._set(estado="error", mensaje="No se pudo cargar el certificado")
            return {"ok": False, "error": f"Certificado inválido o clave incorrecta ({str(e)[:120]})"}

        self._set(estado="activando", mensaje="Autenticando con la DIAN…")
        self._page.goto(f"{CERT_PORTAL}/User/Login", wait_until="domcontentloaded", timeout=45000)
        self._page.wait_for_timeout(2000)

        html = self._page.content()
        if "Client Certificate Required" in html or "403" in (self._page.title() or ""):
            self._set(estado="error", mensaje="La DIAN rechazó el certificado (no presentado).")
            return {"ok": False, "error": "La DIAN no aceptó el certificado. Verifica que sea el correcto y esté vigente."}

        # Tras el login por certificado, ir al portal de documentos (comparte sesión).
        self._page.goto(f"{PORTAL}/Document/Received", wait_until="domcontentloaded", timeout=45000)
        self._page.wait_for_timeout(1200)
        html = self._page.content()
        if "Cerrar sesión" not in html and "LogOut" not in html:
            self._set(estado="error", mensaje="El certificado no abrió sesión de documentos.")
            return {"ok": False, "error": "El certificado autenticó pero no abrió la sesión de documentos. Reintenta."}

        empresa = ""
        try:
            empresa = self._page.locator(".type-person").first.inner_text(timeout=3000).strip()
        except Exception:
            pass

        self._set(estado="activando", mensaje="Esperando validación de seguridad…", empresa=empresa)
        token = self._token_inicial(empresa=empresa)
        if not token:
            self._set(estado="error", mensaje="El captcha no se validó solo. Resuélvelo en la ventana.")
            return {"ok": False, "error": "Turnstile no emitió token. Resuelve el captcha en la ventana y reintenta."}

        self._set(estado="activo", mensaje="Conexión activa (certificado)", empresa=empresa)
        return {"ok": True, "empresa": empresa}

    def _leer_nit_titular(self) -> str:
        """Best-effort: NIT del titular (la cuenta con la que se entró), leído del
        portal, para abrir ZIP cifrados SIN digitarlo (como el Lector de escritorio).
        Devuelve '' si no lo encuentra — entonces se usa el campo manual."""
        import re
        blob = ""
        for sel in (".type-person", ".type-document", "header", ".navbar", ".user-menu"):
            try:
                blob += " " + self._page.locator(sel).first.inner_text(timeout=1200)
            except Exception:
                pass
        m = re.search(r"(?:nit|documento|identificaci[oó]n)\D{0,10}(\d[\d.]{7,11})", blob, re.I)
        if not m:
            m = re.search(r"(?<!\d)(\d{9,10})(?!\d)", blob)
        if m:
            n = re.sub(r"\D", "", m.group(1))
            if 8 <= len(n) <= 10:
                return n
        return ""

    def _ir_token(self, token_url: str):
        """Abre el enlace de la DIAN. El portal redirige varias veces y Chrome
        reporta net::ERR_ABORTED cuando una redirección corta a la anterior: eso
        NO es fallo — después se mira si quedó la sesión («Cerrar sesión»)."""
        try:
            self._page.goto(token_url, wait_until="domcontentloaded", timeout=45000)
        except Exception as e:                                   # noqa: BLE001
            if "ERR_ABORTED" not in str(e) and "interrupted" not in str(e).lower():
                raise

    def _do_activar(self, token_url: str) -> dict:
        self._set(estado="activando", mensaje="Abriendo sesión…")
        # Siempre relanzar limpio: evita chocar con un navegador cerrado/zombie.
        self._relanzar()
        self._ir_token(token_url)
        # ¿Sesión iniciada? Buscar "Cerrar sesión". La DIAN redirige despacio:
        # se espera hasta 20 s en vez de mirar una sola vez a los 1,5 s.
        # A veces el primer intento no arranca (Edison, 1-oct-2026): si no hay
        # sesión, se vuelve a abrir el MISMO enlace una vez más.
        html = ""
        for intento in range(2):
            if intento:
                self._set(estado="activando", mensaje="Segundo intento con el mismo enlace…")
                self._ir_token(token_url)
            for _ in range(20):
                self._page.wait_for_timeout(1000)
                try:
                    html = self._page.content()
                except Exception:
                    continue
                if "Cerrar sesión" in html or "LogOut" in html:
                    break
            if "Cerrar sesión" in html or "LogOut" in html:
                break
        if "Cerrar sesión" not in html and "LogOut" not in html:
            self._set(estado="error", mensaje="El token no inició sesión (¿expiró?)")
            return {"ok": False, "error": "El enlace no inició sesión. Pide un token nuevo en la DIAN."}
        empresa = ""
        try:
            empresa = self._page.locator(".type-person").first.inner_text(timeout=3000).strip()
        except Exception:
            pass

        nit_titular = ""
        try:
            nit_titular = self._leer_nit_titular()
        except Exception:
            pass

        # Ir a Documentos Recibidos, donde vive el widget Turnstile.
        self._page.goto(f"{PORTAL}/Document/Received", wait_until="domcontentloaded", timeout=45000)
        self._set(estado="activando", mensaje="Esperando validación de seguridad…",
                  empresa=empresa, nit_titular=nit_titular)

        token = self._token_inicial(empresa=empresa, nit_titular=nit_titular)
        if not token:
            self._set(estado="error", mensaje="El captcha no se validó solo. Resuélvelo en la ventana.")
            return {"ok": False, "error": "Turnstile no emitió token. Resuelve el captcha en la ventana y reintenta."}

        self._set(estado="activo", mensaje="Conexión activa", empresa=empresa,
                  nit_titular=nit_titular)
        return {"ok": True, "empresa": empresa, "nit_titular": nit_titular}

    def _token_actual(self) -> str:
        try:
            return self._page.eval_on_selector(
                'input[name="cf-turnstile-response"]', "el => el.value"
            ) or ""
        except Exception:
            return ""

    def _token_inicial(self, **datos) -> str:
        """Primer token de Turnstile al abrir la sesión. La DIAN a veces se demora
        más de 45 s o el widget no arranca (Julián, 5-nov-2026: «se corta», y le
        funcionó al reintentar). En vez de fallar a los 45 s: espera, recarga
        Recibidos para reinstanciar el widget, y luego deja hasta 2 min más para
        que el contador resuelva el captcha en la ventana si se lo pide."""
        token = self._esperar_token(timeout=45)
        if token:
            return token
        for intento in range(2):
            self._set(estado="activando",
                      mensaje="La DIAN está lenta: recargando la validación de seguridad…", **datos)
            try:
                self._page.goto(f"{PORTAL}/Document/Received",
                                wait_until="domcontentloaded", timeout=45000)
            except Exception:
                pass
            token = self._esperar_token(timeout=40)
            if token:
                return token
        self._set(estado="activando",
                  mensaje="Si ves un captcha en la ventana de Chrome, márcalo (espero 2 min)…", **datos)
        return self._esperar_token(timeout=120)

    def _esperar_token(self, timeout: float, distinto_de: str | None = None) -> str:
        fin = time.time() + timeout
        while time.time() < fin:
            t = self._token_actual()
            if t and t != (distinto_de or ""):
                return t
            self._page.wait_for_timeout(500)
        return ""

    def _refrescar_token(self, timeout: float = 35) -> str:
        """Fuerza un token nuevo (los de Turnstile son de un solo uso).

        Si el reset no produce token a tiempo, recarga la página de Recibidos
        para reinstanciar el widget y reintenta — así un documento no se cae por
        una demora puntual del captcha.
        """
        viejo = self._token_actual()
        for intento in range(2):
            try:
                self._page.evaluate("() => { try { turnstile.reset(); } catch(e) {} }")
            except Exception:
                pass
            t = self._esperar_token(timeout=timeout, distinto_de=viejo)
            if t:
                return t
            # El widget quedó mudo: recargar Recibidos para reinstanciarlo.
            try:
                self._page.goto(f"{PORTAL}/Document/Received",
                                wait_until="domcontentloaded", timeout=30000)
                self._page.wait_for_timeout(800)
            except Exception:
                pass
            viejo = ""
        return self._token_actual()

    def _buscar_ui(self, fi: str, ff: str, ruta: str = "") -> str:
        """Hace lo que hace una persona: pone las fechas en la bandeja y le da
        «Buscar». Captura el cuerpo de la consulta que dispara el propio portal
        (con las validaciones que lleve) para repetirla página por página.
        Deja _debug_buscar.json y _debug_pagina.html para diagnóstico."""
        import json as _json
        from rutas import DATA_DIR as _DD
        capt = {}

        def _req(req):
            try:
                if req.method == "POST" and "GetDocuments" in req.url:
                    capt.setdefault("post", req.post_data or "")
                    capt.setdefault("url", req.url)
            except Exception:
                pass

        self._page.on("request", _req)
        info = {}
        try:
            info = self._page.evaluate("""([ini, fin]) => {
              const set = (el, v) => {
                const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
                ['input','change','blur'].forEach(t => el.dispatchEvent(new Event(t, {bubbles:true})));
              };
              const fmt = (iso, ej) => {
                const [y, m, d] = iso.split('-');
                if (/^\d{2}\/\d{2}\/\d{4}/.test(ej || '')) return `${d}/${m}/${y}`;
                if (/^\d{4}\/\d{2}\/\d{2}/.test(ej || '')) return `${y}/${m}/${d}`;
                return iso;
              };
              const campos = [], puestos = [];
              for (const el of document.querySelectorAll('input, select, textarea')) {
                const k = ((el.name||'') + ' ' + (el.id||'') + ' ' + (el.placeholder||'')).toLowerCase();
                campos.push({tag: el.tagName, type: el.type, name: el.name, id: el.id,
                             value: String(el.value || '').slice(0, 60), visible: !!el.offsetParent});
                if (el.tagName !== 'INPUT' || ['hidden','checkbox','radio','submit','button'].includes(el.type) && !/date|fecha/.test(k)) continue;
                if (/range/.test(k)) { const v = el.value || ''; const sep = v.includes(' - ') ? ' - ' : ' - ';
                  set(el, fmt(ini, v) + sep + fmt(fin, v.split(sep)[1] || v)); puestos.push(el.id || el.name); }
                else if (/startdate|start_date|fechaini|fecha_ini|fechainicio|desde|initialdate/.test(k)) { set(el, fmt(ini, el.value)); puestos.push(el.id || el.name); }
                else if (/enddate|end_date|fechafin|fecha_fin|hasta|finaldate/.test(k)) { set(el, fmt(fin, el.value)); puestos.push(el.id || el.name); }
              }
              const botones = [...document.querySelectorAll('button, input[type=submit], input[type=button], a')]
                .filter(b => /buscar/i.test((b.innerText || b.value || '').trim()));
              const boton = botones.find(b => b.offsetParent) || botones[0];
              if (boton) boton.click();
              return {campos, puestos, botones: botones.map(b => (b.id || '') + '|' + (b.innerText || b.value || '').trim().slice(0, 30)),
                      clic: !!boton};
            }""", [fi, ff])
        except Exception as e:                                   # noqa: BLE001
            info = {"error": str(e)[:200]}
        for _ in range(30):
            if "post" in capt:
                break
            self._page.wait_for_timeout(500)
        self._page.wait_for_timeout(1500)
        try:
            self._page.remove_listener("request", _req)
        except Exception:
            pass
        try:
            info.update({"ruta": ruta, "capturado": bool(capt.get("post")),
                         "url": capt.get("url"), "post": (capt.get("post") or "")[:3000]})
            _json.dump(info, open(os.path.join(_DD, "_debug_buscar.json"), "w", encoding="utf-8"),
                       ensure_ascii=False, indent=1)
            open(os.path.join(_DD, "_debug_pagina.html"), "w", encoding="utf-8").write(self._page.content())
        except Exception:
            pass
        return capt.get("post") or ""

    def _buscar_en_pagina(self) -> bool:
        """Clic al botón «Buscar» de la bandeja (Recibidos/Enviados) y espera a que
        el portal responda. Sin esto la consulta directa puede volver vacía."""
        for sel in ("button:has-text('Buscar')", "input[type=submit][value*='Buscar']",
                    "a:has-text('Buscar')", "#btnSearch", "button[type=submit]"):
            try:
                loc = self._page.locator(sel).first
                if loc.count() and loc.is_visible():
                    with self._page.expect_response(
                            lambda r: "PageToken" in r.url or "GetDocuments" in r.url,
                            timeout=20000):
                        loc.click(timeout=5000)
                    self._page.wait_for_timeout(800)
                    return True
            except Exception:
                continue
        return False

    def _do_listar(self, fecha_inicio: str, fecha_fin: str, tipo: str = "recibidos") -> dict:
        """Lista los documentos del rango de fechas (sin captcha) y devuelve sus CUFEs.

        Corre la consulta DataTables (/Document/GetDocumentsPageToken) DENTRO de la
        página autenticada, que ya tiene la cookie y el antiforgery token. Pagina
        con continuationToken y extrae los CUFEs (96 hex) de la respuesta cruda.
        """
        if not self._vivo():
            return {"ok": False, "error": "Sesión no activa. Activa el token primero.",
                    "expirado": True}
        # Páginas a consultar. La nómina puede estar en Recibidos o en Enviados
        # según la cuenta, así que se prueban ambas (filtrando por tipo 102).
        if tipo == "recibidos":
            rutas = ["/Document/Received"]
        elif tipo == "nomina":
            rutas = ["/Document/Received", "/Document/Sent"]
        elif tipo == "pos":
            # Documento equivalente electronico (POS): llega como compra.
            rutas = ["/Document/Received", "/Document/Sent"]
        elif tipo == "soporte":
            # Documento soporte en adquisiciones a no obligados: lo emite el
            # comprador, asi que suele estar en Enviados; se prueban los dos.
            rutas = ["/Document/Sent", "/Document/Received"]
        else:
            rutas = ["/Document/Sent"]

        js = """
        async ([ini, fin, tipoDoc, plantilla]) => {
          // Fecha en el mismo formato que usa el portal en su propia consulta.
          const fmt = (iso, ej) => {
            const [y, m, d] = iso.split('-');
            if (/^\d{2}\/\d{2}\/\d{4}/.test(ej || '')) return `${d}/${m}/${y}`;
            if (/^\d{4}\/\d{2}\/\d{2}/.test(ej || '')) return `${y}/${m}/${d}`;
            return iso;
          };
          const tpl = new URLSearchParams(plantilla || '');
          const af = document.querySelector('input[name="__RequestVerificationToken"]');
          const token = af ? af.value : '';
          const LEN = 100;
          let start = 0, cont = '', esNext = false, total = null;
          let docs = {}, cufesAll = {}, pagina = 0, vueltas = 0;   // cufe -> texto de fila
          const re = /[0-9a-f]{96}/i;
          const reAll = /[0-9a-f]{96}/gi;
          const norm = s => s.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();
          // Tipo de documento: '00' = todos (facturas). Para nómina, buscar en el
          // combo "Tipo de documento" la opción que diga "Nómina" y usar su valor.
          // Endpoint y FilterType propios de la pagina actual: la vista de
          // Enviados usa su propia consulta (si se usa la de Recibidos,
          // "ventas" devuelve compras). Se leen de los scripts de la pagina.
          let urlDocs = '/Document/GetDocumentsPageToken';
          let filterType = '3';
          try {
            const htmlScripts = Array.from(document.scripts).map(x => x.textContent || '').join(' ');
            const mu = htmlScripts.match(/["'](\\/Document\\/Get[A-Za-z]*Document[A-Za-z]*PageToken)["']/);
            if (mu) urlDocs = mu[1];
            const mf = htmlScripts.match(/FilterType["']?\\s*[:=]\\s*["']?(\\d+)/i);
            if (mf) filterType = mf[1];
          } catch(e) {}
          let docTypeId = '00';
          let opciones = [];
          try {
            // Primero el combo que de verdad es "Tipo de documento": si se
            // mezclan otros selects se puede elegir un valor que no es del tipo.
            const sels = Array.from(document.querySelectorAll('select'));
            const propio = s => {
              const id = norm((s.name || '') + ' ' + (s.id || ''));
              return id.includes('documenttype') || id.includes('tipodoc');
            };
            const orden = sels.filter(propio).concat(sels.filter(s => !propio(s)));
            for (const sel of orden) {
              for (const opt of (sel.options || [])) {
                const tx = norm(opt.text || '');
                if (tx) opciones.push((opt.value || '') + '|' + tx.slice(0, 60));
              }
            }
          } catch (e) {}
          // Tipos con DocumentTypeId propio. Si el combo no lo trae, se avisa:
          // nunca se cae al '00', que devolveria las facturas otra vez.
          // 'mejor' se busca primero (opcion exacta); 'si' es el respaldo.
          const REGLAS = {
            nomina:  { mejor: ['nomina individual'], si: ['nomina'], no: [] },
            soporte: { mejor: ['soporte en adquisiciones', 'adquisiciones'],
                       si: ['soporte'],
                       no: ['nomina', 'nota de ajuste', 'ajuste al documento'] },
            pos:     { mejor: ['equivalente electronico', 'tiquete de maquina'],
                       si: ['equivalente', 'tiquete', 'pos'],
                       no: ['nomina', 'nota de ajuste', 'ajuste al documento'] }
          };
          const regla = REGLAS[tipoDoc];
          if (regla) {
            let hallado = '';
            const buscar = (claves) => {
              for (const par of opciones) {
                const i = par.indexOf('|');
                const val = par.slice(0, i), tx = par.slice(i + 1);
                if (!val || val === '00') continue;
                if (regla.no.some(x => tx.includes(x))) continue;
                if (claves.some(x => tx.includes(x))) return val;
              }
              return '';
            };
            hallado = buscar(regla.mejor || []) || buscar(regla.si || []);
            if (!hallado) {
              return { error: 'En esta pagina de la DIAN no aparece el tipo "'
                              + tipoDoc + '"', opciones: opciones, sinTipo: true };
            }
            docTypeId = hallado;
          }
          while (vueltas < 300) {
            vueltas++;
            const b = new URLSearchParams();
            b.append('draw', String(vueltas));
            b.append('start', String(start));
            b.append('length', String(LEN));
            b.append('DocumentKey',''); b.append('SerieAndNumber','');
            b.append('SenderCode',''); b.append('ReceiverCode','');
            b.append('StartDate', ini); b.append('EndDate', fin);
            b.append('DocumentTypeId', docTypeId);
            b.append('Status','0');
            b.append('IsNextPage', esNext ? 'true' : 'false');
            b.append('FilterType', filterType);
            b.append('blockIndex', String(pagina));
            b.append('RadianStatus','0');
            b.append('ContinuationToken', cont || '');
            if (token) b.append('__RequestVerificationToken', token);
            // Lo que el portal mande en SU consulta (validaciones, filtros) se
            // respeta; solo se controlan paginación, fechas y tipo.
            if (plantilla) {
              const propios = ['draw','start','length','StartDate','EndDate','DocumentTypeId',
                               'IsNextPage','blockIndex','ContinuationToken'];
              for (const [k, v] of tpl.entries()) if (!propios.includes(k)) b.set(k, v);
              b.set('StartDate', fmt(ini, tpl.get('StartDate')));
              b.set('EndDate', fmt(fin, tpl.get('EndDate')));
            }
            let txt;
            try {
              const r = await fetch(urlDocs, {
                method:'POST', headers:{'X-Requested-With':'XMLHttpRequest'}, body: b });
              txt = await r.text();
            } catch(e) { return {error: String(e)}; }
            let d; try { d = JSON.parse(txt); } catch(e) { return {error:'respuesta no JSON', raw: txt.slice(0,300)}; }
            if (total === null) total = d.recordsTotal || d.recordsFiltered || 0;
            // Base robusta: todos los CUFE que aparezcan en la respuesta.
            (txt.match(reAll) || []).forEach(c => cufesAll[c.toLowerCase()] = 1);
            const filas = d.data || [];
            // Por fila: CUFE + texto (para saber el tipo y poder filtrar nómina).
            filas.forEach(row => {
              const s = (Array.isArray(row) ? row.join(' ') : JSON.stringify(row)) || '';
              const m = s.match(re);
              if (m) { const c = m[0].toLowerCase(); if (!(c in docs)) docs[c] = norm(s).slice(0, 2500); }
            });
            const n = filas.length;
            cont = d.continuationToken || d.ContinuationToken || '';
            esNext = true; pagina++; start += (n || LEN);
            if (!n) break;
            if (!cont && start >= (total || 0)) break;
          }
          return { total, docs, cufes: Object.keys(cufesAll), docTypeId,
                   urlDocs, filterType, opciones };
        }
        """
        r = {}
        r_err = {}
        ultimo_error = ""
        ruta_ok = ""
        for ruta in rutas:
            try:
                if ruta.lower() not in (self._page.url or "").lower():
                    self._page.goto(f"{PORTAL}{ruta}", wait_until="domcontentloaded", timeout=30000)
                    self._page.wait_for_timeout(800)
            except Exception:
                pass
            # El portal no responde la consulta hasta que se le da «Buscar» en la
            # página (Edison, 1-oct-2026: «tienes que buscar primero»).
            plantilla = self._buscar_ui(fecha_inicio, fecha_fin, ruta)
            try:
                rr = self._page.evaluate(js, [fecha_inicio, fecha_fin, tipo, plantilla])
            except Exception as e:
                ultimo_error = f"Error al listar: {str(e)[:120]}"
                continue
            if rr.get("error"):
                ultimo_error = rr["error"]
                r_err = rr
                continue
            r = rr
            ruta_ok = ruta
            if rr.get("cufes") or rr.get("total"):   # encontró algo → no seguir
                break
        if not r:
            return {"ok": False, "error": ultimo_error or "No se pudo listar",
                    "opciones": (r_err or {}).get("opciones", [])}
        docs = r.get("docs", {}) or {}
        base = [c for c in r.get("cufes", []) if len(c) == 96]

        def es_nomina(txt):
            # "nomina" tiene que venir acompañada de una palabra del tipo de
            # documento de la DIAN ("Nómina Individual", "de ajuste"...). Así un
            # proveedor llamado "SERVICIOS DE NOMINA SAS" no pierde su factura.
            t = txt or ""
            return ("nomina individual" in t or "nomina electronica" in t
                    or "nomina de ajuste" in t or "ajuste de nomina" in t
                    or "documento soporte de pago" in t or ">nie<" in t)

        # Diagnóstico (incluye el tipo de documento que se usó en la DIAN).
        try:
            import json as _json
            from rutas import DATA_DIR as _DD
            muestra = [{"cufe": c[:12], "texto": t[:180]} for c, t in list(docs.items())[:25]]
            _json.dump({"tipo": tipo, "ruta": ruta_ok, "docTypeId": r.get("docTypeId"),
                        "opciones": r.get("opciones", []),
                        "urlDocs": r.get("urlDocs"), "filterType": r.get("filterType"),
                        "total": r.get("total"), "docs": len(docs),
                        "cufes_base": len(base), "muestra": muestra},
                       open(os.path.join(_DD, "_debug_listado.json"), "w", encoding="utf-8"),
                       ensure_ascii=False, indent=2)
        except Exception:
            pass

        def _texto_de(tipo_, txt):
            """¿La fila del listado corresponde al tipo pedido?

            Red de seguridad por si la DIAN ignorara el DocumentTypeId: con
            'soporte' o 'pos' solo pasan las filas cuyo texto lo confirma, así
            nunca se cuelan todas las compras.
            """
            t = txt or ""
            if tipo_ == "soporte":
                return "soporte" in t and "nomina" not in t
            if tipo_ == "pos":
                return ("documento equivalente" in t or "equivalente electronico" in t
                        or "tiquete de maquina" in t or "maquina registradora" in t
                        or "tiquete" in t)
            return True

        def es_acuse(txt):
            # "ApplicationResponse" / acuses / eventos RADIAN: valor $0, no se bajan.
            t = txt or ""
            return "application" in t or "acuse de recibo" in t \
                or "documento de aplicacion" in t or "instrumento electronico" in t

        if tipo in ("pos", "soporte"):
            # Estrictos: además del DocumentTypeId de la DIAN, la fila tiene que
            # decir que es de ese tipo. Sin texto de fila, no entra.
            cufes = [c for c in base
                     if docs.get(c) and _texto_de(tipo, docs.get(c, ""))
                     and not es_acuse(docs.get(c, ""))]
        elif tipo == "nomina":
            # El DocumentTypeId ya filtró a "Nómina Individual" en la DIAN.
            cufes = base
        elif tipo in ("enviados", "emitidos"):
            # Facturas de venta: excluir nómina y acuses (valor 0) que se cuelen.
            cufes = [c for c in base if not es_nomina(docs.get(c, "")) and not es_acuse(docs.get(c, ""))]
        else:
            # Recibidos (compras): se incluyen también los acuses / ApplicationResponse
            # (eventos RADIAN) — se guardan aparte y sirven para la auditoría de
            # acuses de las facturas a crédito; no entran a los planos.
            # Lo que SÍ se saca: nómina, documento soporte y equivalentes POS,
            # que tienen su propia casilla y no son facturas de compra.
            def _otro_tipo(c):
                t = docs.get(c, "")
                if not t:
                    return False          # sin texto de fila: no se descarta
                # FRASES completas, nunca palabras sueltas: un proveedor que se
                # llame "AGENCIA DE TIQUETES" o "SERVICIOS DE NOMINA" no puede
                # hacer que se pierda una compra real.
                return (es_nomina(t)
                        or ("documento soporte" in t and "nomina" not in t)
                        or "documento equivalente" in t
                        or "equivalente electronico" in t
                        or "tiquete de maquina" in t
                        or "maquina registradora" in t)
            cufes = [c for c in base if not _otro_tipo(c)]
        return {"ok": True, "total": r.get("total"), "cufes": cufes}

    def _do_descargar(self, cufe: str, passwords=(), intentos: int = 5) -> dict:
        """Descarga un CUFE con reintentos ante fallos puntuales de captcha/red."""
        if not self._vivo():
            self._set(estado="expirado",
                      mensaje="La ventana de Chrome se cerró. Dale «Activar token» para reanudar.")
            return {"ok": False, "cufe": cufe,
                    "error": "La ventana de Chrome se cerró. Reactiva el token para reanudar.",
                    "expirado": True}
        if self.estado()["estado"] not in ("activo",):
            return {"ok": False, "cufe": cufe, "error": "Sesión no activa", "expirado": True}
        if not cufe or len(cufe) < 20:
            return {"ok": False, "cufe": cufe, "error": "CUFE inválido"}

        ultimo_error = ""
        for intento in range(1, intentos + 1):
            r = self._intentar_descarga(cufe, passwords)
            if r.get("ok") or r.get("expirado"):
                return r
            ultimo_error = r.get("error", "Error")
            # Backoff progresivo. Si fue error de RED (la DIAN cortó la conexión:
            # socket hang up / TLS / timeout), espera MÁS para que su servidor se
            # recupere; si fue captcha, una pausa breve basta.
            es_red = ultimo_error.startswith("Red:") or "Timeout" in ultimo_error
            self._page.wait_for_timeout((2800 if es_red else 1200) * intento)
        return {"ok": False, "cufe": cufe,
                "error": f"{ultimo_error} (tras {intentos} intentos)"}

    def _intentar_descarga(self, cufe: str, passwords=()) -> dict:
        token = self._refrescar_token()
        if not token:
            return {"ok": False, "cufe": cufe, "error": "No se obtuvo token de captcha"}

        url = f"{PORTAL}/Document/DownloadZipFiles?trackId={cufe}&captcha={token}"
        # request del contexto → comparte cookies de sesión del navegador.
        try:
            resp = self._ctx.request.get(url, timeout=60000)
        except Exception as e:
            return {"ok": False, "cufe": cufe, "error": f"Red: {str(e)[:80]}"}
        ct = resp.headers.get("content-type", "")
        cuerpo = resp.body()

        # ¿La sesión expiró? La DIAN redirige al login (AuthToken/Acceder).
        final = (resp.url or "").lower()
        if "authtoken" in final or "/user/" in final or (b"DIAN | Acceder" in cuerpo[:3000]):
            self._set(estado="expirado", mensaje="La sesión expiró. Pide un token nuevo y reanuda.")
            return {"ok": False, "cufe": cufe, "error": "Sesión expirada", "expirado": True}

        if resp.status != 200 or ("zip" not in ct and cuerpo[:2] != b"PK"):
            # Suele redirigir a SearchInvalidQR si el captcha/CUFE falla.
            return {"ok": False, "cufe": cufe,
                    "error": f"La DIAN no entregó el ZIP (status {resp.status}, {ct or 'sin tipo'})"}

        xmls, motivo = zip_utils.leer_xmls(cuerpo, passwords, dump_dir=DEBUG_CIFRADO)
        if not xmls:
            err = f"El ZIP {motivo}" if motivo else "El ZIP no contenía XML"
            return {"ok": False, "cufe": cufe, "error": err}
        return {"ok": True, "cufe": cufe, "xmls": xmls}

    @staticmethod
    def _extraer_xml(zip_bytes: bytes) -> list[tuple[str, bytes]]:
        salida = []
        try:
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
        except zipfile.BadZipFile:
            # A veces el cuerpo ya es el XML directo.
            if zip_bytes.lstrip()[:5] == b"<?xml" or b"<Invoice" in zip_bytes[:400]:
                return [("documento.xml", zip_bytes)]
            return []
        for n in zf.namelist():
            if n.lower().endswith(".xml") and not n.startswith("__MACOSX"):
                salida.append((os.path.basename(n), zf.read(n)))
        return salida

    def _do_cerrar(self):
        try:
            if self._ctx:
                self._ctx.close()
        finally:
            self._ctx = None
            self._page = None
            self._set(estado="inactivo", mensaje="", empresa="")


# Instancia única para la app.
SESION = DianSession()
