' Descargador Tributando - lanzador SIN ventana negra.
' El contador hace doble clic en ESTE archivo (.vbs). Corre el programa
' oculto y abre Chrome; no se ve ninguna consola.
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
' Arranca el motor oculto (0 = ventana oculta, False = no esperar)
sh.CurrentDirectory = carpeta
sh.Run """" & carpeta & "\_motor.bat""", 0, False
