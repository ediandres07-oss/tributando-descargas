@echo off
chcp 65001 >nul
title Crear icono - Descargador Tributando
cd /d "%~dp0"
call "%~dp0_icono.bat"
echo(
echo  ================================================================
echo    LISTO: se creo el icono "Descargador Tributando" (con el logo)
echo    en tu ESCRITORIO y en el menu Inicio.
echo(
echo    Para ANCLARLO a la barra de tareas de abajo:
echo      1) Ve a tu Escritorio
echo      2) Clic DERECHO sobre "Descargador Tributando"
echo      3) "Mostrar mas opciones"  ^>  "Anclar a la barra de tareas"
echo(
echo    (o solo abrelo con doble clic desde el Escritorio)
echo  ================================================================
echo(
pause
