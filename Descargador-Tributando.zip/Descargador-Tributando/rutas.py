"""Rutas de código (solo lectura, dentro del paquete) y de datos (escribibles).

Empaquetado con PyInstaller, el código vive en una carpeta temporal de solo
lectura (sys._MEIPASS), así que los datos que la app escribe (consultas,
perfiles, licencia, perfil de Chrome, subidas) deben ir a una carpeta del
usuario. En desarrollo, ambos son la carpeta del proyecto.
"""
from __future__ import annotations

import os
import sys

# Base del CÓDIGO (templates, estáticos): dentro del paquete si está congelado.
CODE_BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))

# Base de DATOS (escribible).
if getattr(sys, "frozen", False):
    if sys.platform == "darwin":
        DATA_DIR = os.path.expanduser("~/Library/Application Support/LectorXML")
    elif sys.platform.startswith("win"):
        DATA_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "LectorXML")
    else:
        DATA_DIR = os.path.expanduser("~/.lectorxml")
else:
    DATA_DIR = os.path.dirname(os.path.abspath(__file__))

os.makedirs(DATA_DIR, exist_ok=True)


def data(*partes) -> str:
    """Ruta dentro de la carpeta de datos escribible."""
    return os.path.join(DATA_DIR, *partes)
