"""Lectura robusta de ZIP de la DIAN.

La DIAN a veces entrega el ZIP de la factura PROTEGIDO con contraseña: la clave
es el NIT de la empresa (o la cédula, para persona natural) del titular. Antes,
`zipfile.read()` sin contraseña lanzaba error y el CUFE quedaba como "no se pudo
leer". Aquí probamos el NIT/cédula del cliente y, si el cifrado es AES, usamos
pyzipper (si está disponible). Nunca lanza: si no puede, devuelve el motivo para
mostrarlo y sigue con los demás documentos del lote.
"""
from __future__ import annotations

import io
import os
import hashlib
import zipfile


def _candidatos(passwords) -> list[str]:
    """Contraseñas a probar a partir del NIT/cédula del cliente.

    Cubre las formas en que puede venir guardado: con o sin dígito de
    verificación (`900513892-1`), con puntos/espacios, o solo los dígitos.
    """
    cands: list[str] = []

    def add(v):
        v = (v or "").strip()
        if v and v not in cands:
            cands.append(v)

    for p in passwords or ():
        s = str(p or "").strip()
        add(s)
        add("".join(ch for ch in s if ch.isdigit()))   # solo dígitos (NIT+DV pegados)
        if "-" in s:                                     # NIT sin el DV
            base = s.split("-")[0]
            add(base)
            add("".join(ch for ch in base if ch.isdigit()))
    return cands


def leer_xmls(zip_bytes: bytes, passwords=(), dump_dir: str | None = None):
    """Devuelve (xmls, motivo).

    xmls = [(nombre, bytes)] de los .xml del ZIP. `motivo` es "" si todo bien, o
    un texto explicando por qué algún XML cifrado no se pudo abrir. Si un ZIP
    protegido no se pudo abrir y `dump_dir` está dado, guarda una copia cruda
    para diagnóstico.
    """
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        # A veces el cuerpo ya es el XML directo.
        if zip_bytes.lstrip()[:5] == b"<?xml" or b"<Invoice" in zip_bytes[:400]:
            return [("documento.xml", zip_bytes)], ""
        return [], "el archivo no es un ZIP válido"

    cands = _candidatos(passwords)
    salida: list[tuple[str, bytes]] = []
    motivo = ""
    hubo_cifrado_fallido = False

    for zi in zf.infolist():
        n = zi.filename
        if not n.lower().endswith(".xml") or n.startswith("__MACOSX"):
            continue
        if not (zi.flag_bits & 0x1):        # entrada NO cifrada → camino normal
            salida.append((os.path.basename(n), zf.read(n)))
            continue
        data = _leer_cifrado(zip_bytes, zf, n, cands)
        if isinstance(data, (bytes, bytearray)):
            salida.append((os.path.basename(n), bytes(data)))
        else:
            motivo = motivo or data
            hubo_cifrado_fallido = True

    if hubo_cifrado_fallido and dump_dir:
        _guardar_muestra(zip_bytes, dump_dir)

    return salida, motivo


def _leer_cifrado(zip_bytes, zf, nombre, cands):
    """Devuelve bytes si logra descifrar, o un str con el motivo del fallo."""
    if not cands:
        return "está protegido con contraseña y no hay NIT/cédula del cliente para intentar"

    # 1) ZipCrypto (lo abre la librería estándar de Python)
    aes = False
    for pw in cands:
        try:
            return zf.read(nombre, pwd=pw.encode())
        except NotImplementedError:
            aes = True            # compresión/cifrado AES → intentar con pyzipper
            break
        except (RuntimeError, zipfile.BadZipFile):
            continue              # contraseña incorrecta, probar la siguiente

    # 2) AES (WinZip) → requiere pyzipper
    try:
        import pyzipper
    except ImportError:
        if aes:
            return "usa cifrado AES: falta instalar pyzipper (pip install pyzipper) y recompilar"
        # No era AES; simplemente ninguna contraseña sirvió.
        return "está protegido: la contraseña no fue el NIT ni la cédula del cliente"

    try:
        with pyzipper.AESZipFile(io.BytesIO(zip_bytes)) as az:
            for pw in cands:
                try:
                    az.setpassword(pw.encode())
                    return az.read(nombre)
                except Exception:
                    continue
    except Exception:
        pass
    return "está protegido: la contraseña no fue el NIT ni la cédula del cliente"


def _guardar_muestra(zip_bytes: bytes, dump_dir: str) -> None:
    """Guarda una copia del ZIP protegido para poder diagnosticar el cifrado."""
    try:
        os.makedirs(dump_dir, exist_ok=True)
        h = hashlib.sha1(zip_bytes).hexdigest()[:10]
        ruta = os.path.join(dump_dir, f"lector_cifrado_{h}.zip")
        if not os.path.exists(ruta):
            with open(ruta, "wb") as fh:
                fh.write(zip_bytes)
    except Exception:
        pass
