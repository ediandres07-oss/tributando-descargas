"""Descargador Tributando → Nube (mini-programa local).

Hace UNA sola cosa: con el enlace/token del correo de la DIAN del cliente,
baja en lote sus documentos (recibidos y/o enviados) y los SUBE a la app
contable en la nube, donde se reparten por NIT y —si el servidor lo tiene
activado— se contabilizan solos.

Corre local porque el portal de la DIAN exige un navegador real (captcha
Turnstile); todo lo demás vive en la nube. Reusa `dian_descargador.py` del
Lector tal cual (copiado, no tocado).

Uso:  pip install -r requirements.txt && playwright install chromium
      python3 app.py   →  http://127.0.0.1:5077
"""
from __future__ import annotations

import io
import json
import os
import threading
import urllib.request
import uuid
from datetime import date, timedelta

import sys
from flask import Flask, jsonify, render_template_string, request

from rutas import DATA_DIR

app = Flask(__name__)
CONFIG = os.path.join(DATA_DIR, "descargador_nube.json")
NUBE_DEFAULT = "https://contabilidad-tributando.onrender.com"
VERSION = "1.2.7"     # subir en cada release; el aviso compara contra version.txt del repo
REPO_RAW = "https://raw.githubusercontent.com/ediandres07-oss/tributando-descargas/main"

# Estado del trabajo en curso (una sola tarea a la vez; UI hace polling).
ESTADO = {"fase": "quieto", "detalle": "", "total": 0, "hechos": 0,
          "errores": [], "resumen": None, "inicio": 0}
_LOCK = threading.Lock()


def _cfg_leer() -> dict:
    try:
        return json.load(open(CONFIG, encoding="utf-8"))
    except Exception:
        return {}


def _cfg_guardar(d: dict):
    json.dump(d, open(CONFIG, "w", encoding="utf-8"))


def _set(**kw):
    with _LOCK:
        ESTADO.update(kw)


def _subir_nube(nube: str, email: str, clave: str, nit: str,
                archivos: list[tuple[str, bytes]]) -> dict:
    """POST multipart a /api/lector/ingresar (sin dependencias externas)."""
    frontera = uuid.uuid4().hex
    cuerpo = io.BytesIO()

    def campo(nombre, valor):
        cuerpo.write(f"--{frontera}\r\nContent-Disposition: form-data; "
                     f"name=\"{nombre}\"\r\n\r\n{valor}\r\n".encode())

    campo("email", email)
    campo("clave", clave)
    campo("nit", nit)
    for nombre, data in archivos:
        cuerpo.write(f"--{frontera}\r\nContent-Disposition: form-data; "
                     f"name=\"archivos\"; filename=\"{nombre}\"\r\n"
                     f"Content-Type: application/xml\r\n\r\n".encode())
        cuerpo.write(data)
        cuerpo.write(b"\r\n")
    cuerpo.write(f"--{frontera}--\r\n".encode())
    req = urllib.request.Request(
        nube.rstrip("/") + "/api/lector/ingresar", data=cuerpo.getvalue(),
        headers={"Content-Type": f"multipart/form-data; boundary={frontera}"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read())


def _carpeta_local(empresa: str, nit: str, fi: str, ff: str, manual: bool) -> str:
    """Carpeta donde queda la copia de los XML en el computador (14-oct-2026).

    Documentos/XML Tributando/<Empresa (NIT)>/<desde> a <hasta>. Así el contador
    tiene los XML aunque no use la nube (exógena Bogotá, auditorías, otro software).
    """
    import re
    import time as _t
    casa = os.path.expanduser("~")
    base = next((os.path.join(casa, d) for d in ("Documents", "Documentos")
                 if os.path.isdir(os.path.join(casa, d))), casa)
    nombre = re.sub(r'[\\/:*?"<>|]+', " ", (empresa or "").strip()).strip()[:60]
    cli = (f"{nombre} ({nit})" if nombre and nit else nombre or (f"NIT {nit}" if nit else "Sin NIT"))
    rango = (f"CUFE pegados {_t.strftime('%Y-%m-%d %H%M')}" if manual
             else f"{fi} a {ff}")
    ruta = os.path.join(base, "XML Tributando", cli, rango)
    os.makedirs(ruta, exist_ok=True)
    return ruta


def _trabajo(datos: dict):
    """Hilo de trabajo: activar token → listar → descargar → subir a la nube."""
    from dian_descargador import SESION
    try:
        _set(fase="activando", detalle="Abriendo sesión con el token de la DIAN…",
             errores=[], resumen=None, total=0, hechos=0, inicio=__import__("time").time())
        r = SESION.activar(datos["token"])
        if not r.get("ok"):
            _set(fase="error", detalle=r.get("error") or r.get("mensaje")
                 or "No se pudo activar el token.")
            return
        empresa = r.get("empresa", "")
        nit_portal = r.get("nit_titular", "")   # NIT leído del portal (respaldo)
        # El NIT del titular viene EN EL TOKEN de la DIAN, en el parámetro rk
        # (ej. ...&rk=900862924&...). Es la fuente más confiable para abrir ZIP.
        import urllib.parse as _up
        def _nit_de_token(u):
            try:
                rk = (_up.parse_qs(_up.urlparse(u).query).get("rk") or [""])[0]
                rk = "".join(c for c in rk if c.isdigit())
                return rk if 6 <= len(rk) <= 12 else ""
            except Exception:
                return ""
        nit_token = _nit_de_token(datos.get("token", ""))
        nit_auto = nit_token or nit_portal      # el del token manda

        # CUFEs a bajar: pegados a mano (prioridad) o listados por rango de fechas.
        manual = datos.get("cufes_manual") or []
        cufes = []
        if manual:
            for c in manual:
                if c not in cufes:
                    cufes.append(c)
            _set(fase="listando",
                 detalle=f"{len(cufes)} CUFE pegados a mano: se bajan directo.")
        else:
            for tipo in datos["tipos"]:
                _set(fase="listando", detalle=f"Listando {tipo} ({datos['fi']} → {datos['ff']})…")
                rl = SESION.listar(datos["fi"], datos["ff"], tipo)
                if not rl.get("ok"):
                    _set(fase="error", detalle=f"Listado de {tipo}: {rl.get('error')}")
                    return
                cufes += [c for c in rl.get("cufes", []) if c not in cufes]
        if not cufes:
            _set(fase="listo", detalle="No hay documentos para bajar.",
                 resumen={"nuevas": 0})
            return

        solo_local = not (datos.get("email") and datos.get("clave"))
        try:
            carpeta = _carpeta_local(empresa, nit_auto or datos.get("nit", ""),
                                     datos.get("fi", ""), datos.get("ff", ""), bool(manual))
        except Exception:
            carpeta = os.path.join(DATA_DIR, "xml")
            os.makedirs(carpeta, exist_ok=True)

        # Reanudar sin repetir: la nube dice qué CUFEs ya tiene y se saltan.
        ya = set()
        try:
            if solo_local:
                raise RuntimeError("sin cuenta: no se consulta la nube")
            _set(fase="listando", detalle="Consultando qué ya está en la nube…")
            import urllib.parse
            cuerpo = urllib.parse.urlencode({"email": datos["email"],
                                             "clave": datos["clave"]}).encode()
            req = urllib.request.Request(
                datos["nube"].rstrip("/") + "/api/lector/cufes", data=cuerpo,
                headers={"Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=60) as rr:
                rj = json.loads(rr.read())
            if rj.get("ok"):
                ya = set(rj.get("cufes", []))
        except Exception:
            pass                      # si falla, se descargan todos (la nube deduplica)
        saltados = len([c for c in cufes if c in ya])
        cufes = [c for c in cufes if c not in ya]
        if not cufes:
            _set(fase="listo", detalle=f"Todo ya estaba en la nube ({saltados} documentos).",
                 resumen={"nuevas": 0, "duplicadas": saltados, "carpeta": carpeta})
            return

        _set(fase="descargando", total=len(cufes), hechos=0,
             detalle=f"{empresa}"
             + (f" · NIT {nit_auto} (auto)" if nit_auto else " · NIT no detectado (usa el campo)")
             + f": {len(cufes)} por bajar"
             + (f" ({saltados} ya estaban en la nube)" if saltados else ""))
        pendientes, errores = [], []
        # Claves de ZIP cifrado (automático, como el Lector): el NIT del token (rk),
        # el del portal, y el del campo si lo digitaste. Se prueban todas, con y sin
        # dígito de verificación.
        pwds = []
        for _n in (nit_token, nit_portal, datos["nit"]):
            _n = (_n or "").strip()
            if _n and _n not in pwds:
                pwds.append(_n)
                if len(_n) >= 10 and _n[:-1] not in pwds:
                    pwds.append(_n[:-1])        # sin dígito de verificación
        enviadas_total = {"nuevas": 0, "duplicadas": 0, "causadas": 0,
                          "sin_empresa": 0, "empresas_creadas": 0,
                          "por_empresa": {}, "sin_empresa_det": {},
                          "carpeta": carpeta, "guardados": 0, "solo_local": solo_local}

        def _copia_local(nombre, data):
            """Copia de cada XML en el computador, antes de subirlo (nada depende de la nube)."""
            try:
                destino = os.path.join(carpeta, os.path.basename(nombre))
                raiz, ext = os.path.splitext(destino)
                n = 1
                while os.path.exists(destino):          # mismo nombre: ¿es el mismo XML?
                    with open(destino, "rb") as fh:
                        if fh.read() == data:
                            return                       # ya estaba: no se duplica
                    n += 1
                    destino = f"{raiz} ({n}){ext}"       # otro documento con igual nombre
                with open(destino, "wb") as fh:
                    fh.write(data)
                enviadas_total["guardados"] += 1
            except Exception as ex:
                errores.append(f"{nombre[:14]}…: no se pudo guardar en el computador ({ex})")

        def _subir(archs):
            rs = _subir_nube(datos["nube"], datos["email"], datos["clave"],
                             datos["nit"], archs)
            if not rs.get("ok"):
                raise RuntimeError(rs.get("error", "La nube rechazó la subida."))
            for k in ("nuevas", "duplicadas", "causadas", "sin_empresa", "empresas_creadas"):
                enviadas_total[k] += rs.get(k, 0)
            for k, v in (rs.get("por_empresa") or {}).items():
                enviadas_total["por_empresa"][k] = enviadas_total["por_empresa"].get(k, 0) + v
            for k, v in (rs.get("sin_empresa_det") or {}).items():
                enviadas_total["sin_empresa_det"][k] = v
            errores.extend(rs.get("errores") or [])

        def _guardar_fallido(nombre, data):
            """Lo que la nube no recibió queda en disco: nada se pierde."""
            try:
                carpeta = os.path.join(DATA_DIR, "fallidos")
                os.makedirs(carpeta, exist_ok=True)
                with open(os.path.join(carpeta, os.path.basename(nombre)), "wb") as fh:
                    fh.write(data)
            except Exception:
                pass

        def _enviar_lote():
            nonlocal pendientes
            if not pendientes:
                return True
            if solo_local:              # sin cuenta: ya quedó la copia local, no se sube
                pendientes = []
                return True
            lote, pendientes = pendientes, []
            _set(fase="subiendo", detalle=f"Subiendo {len(lote)} XML a la nube…")
            try:
                _subir(lote)
                return True
            except Exception as ex:
                primero = ex
            # La nube rechazó el lote completo (un 500 por UN documento raro
            # tumbaba los 25). Se reintenta de a 5; lo que siga fallando se
            # guarda en fallidos/ y se anota, y la descarga SIGUE con el resto.
            _set(fase="subiendo",
                 detalle=f"La nube rechazó un lote de {len(lote)} ({primero}); reintentando de a 5…")
            for i in range(0, len(lote), 5):
                sub = lote[i:i + 5]
                try:
                    _subir(sub)
                except Exception as ex2:
                    for nombre, data in sub:
                        _guardar_fallido(nombre, data)
                        errores.append(f"{nombre[:14]}…: la nube no lo recibió ({ex2}); "
                                       f"quedó en fallidos/ para reintentar")
            return True

        for i, cufe in enumerate(cufes, 1):
            _set(fase="descargando", hechos=i - 1,
                 detalle=f"Descargando {i}/{len(cufes)}…")
            rd = SESION.descargar(cufe, passwords=pwds)
            if rd.get("expirado"):
                _set(fase="error", detalle="La sesión de la DIAN expiró. "
                     "Vuelve a activar el token y repite.")
                return
            if rd.get("ok"):
                for nombre, data in rd.get("xmls", []):
                    _copia_local(nombre, data)
                    pendientes.append((os.path.basename(nombre), data))
            else:
                errores.append(f"{cufe[:12]}…: {rd.get('error', 'error')}")
            if len(pendientes) >= 25 and not _enviar_lote():
                return
        if not _enviar_lote():
            return
        if solo_local:
            enviadas_total["nuevas"] = enviadas_total["guardados"]
        _set(fase="listo", hechos=len(cufes),
             detalle="Terminado.", errores=errores,
             resumen=enviadas_total)
    except Exception as ex:
        _set(fase="error", detalle=f"Fallo inesperado: {ex}")


PAGINA = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<title>Descargador Tributando → Nube</title>
<style>
 body{font-family:-apple-system,'Segoe UI',sans-serif;background:#12161f;color:#eef1f6;
      max-width:640px;margin:24px auto;padding:0 16px}
 h1{font-size:1.25rem;color:#e6c483} .sub{color:#9aa3b2;font-size:.85rem}
 label{display:block;margin-top:10px;font-size:.8rem;color:#c2c9d4}
 input{width:100%;padding:10px;border-radius:9px;border:1px solid #39415a;
       background:#1b2130;color:#fff;font-size:.9rem;box-sizing:border-box}
 .fila{display:flex;gap:10px} .fila>div{flex:1}
 button{margin-top:16px;width:100%;padding:13px;border:0;border-radius:10px;
        background:#cda766;color:#1e2432;font-weight:800;font-size:1rem;cursor:pointer}
 button:disabled{opacity:.5}
 @keyframes tluz{0%,100%{box-shadow:0 0 0 0 rgba(55,211,143,.7)}50%{box-shadow:0 0 10px 4px rgba(55,211,143,.25)}}
 .btn-activo{background:#37d38f !important;color:#0e1b14 !important;animation:btnluz 1.35s ease-in-out infinite}
 @keyframes btnluz{0%,100%{box-shadow:0 0 4px 1px rgba(55,211,143,.55)}50%{box-shadow:0 0 34px 11px rgba(55,211,143,.65)}}
 #estado{margin-top:16px;padding:12px;border-radius:10px;background:#1b2130;
         border-left:4px solid #cda766;font-size:.9rem;display:none;white-space:pre-wrap}
 .chk{display:inline-flex;gap:7px;align-items:center;font-size:.85rem;cursor:pointer;
      background:#1b2130;border:1px solid #2a3145;border-radius:9px;padding:8px 13px}
 .barra{height:8px;background:#2a3145;border-radius:6px;margin-top:8px;overflow:hidden}
 .barra i{display:block;height:100%;background:#cda766;width:0%}
</style></head><body>
<div id="avisoVersion" style="display:none;background:#2a2113;border:1px solid #cda766;border-radius:11px;padding:12px 16px;margin:0 0 14px;color:#f2d99f;font-size:.9rem">
  <b>Hay una versión nueva del Descargador.</b>
  <span style="color:#cbb98a">Descárgala, descomprime y reemplaza la carpeta vieja por la nueva.</span>
  <a id="avisoLink" href="#" style="display:inline-block;margin-left:6px;background:#cda766;color:#1E2432;text-decoration:none;font-weight:700;padding:6px 13px;border-radius:8px">Descargar la actualización</a>
</div>
<div style="text-align:center;margin:4px 0 10px">
  <img src="/static/logo-tributando.png" alt="Tributando"
       style="width:64px;height:64px;border-radius:50%;box-shadow:0 4px 14px rgba(0,0,0,.45)">
</div>
<h1 style="text-align:center;margin-top:0">Descargador → Nube</h1>
<p class="sub">Pega el enlace del correo de la DIAN del cliente: se descargan sus
documentos, queda una copia de los XML en tu computador (Documentos › XML Tributando) y,
si pones tu cuenta de Tributando, se contabilizan solos en la nube.</p>
<p style="margin:-4px 0 14px">
  <a href="https://contabilidad-tributando.onrender.com" target="_blank" rel="noopener"
     style="display:inline-flex;align-items:center;gap:7px;background:#cda766;color:#1E2432;
            text-decoration:none;font-weight:600;padding:9px 16px;border-radius:9px">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="#1E2432" style="vertical-align:-3px">
      <rect x="3" y="12" width="4.2" height="9" rx="1.2"/>
      <rect x="9.9" y="7" width="4.2" height="14" rx="1.2"/>
      <rect x="16.8" y="3.5" width="4.2" height="17.5" rx="1.2"/>
    </svg>
    Ir a mi contabilidad
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1E2432" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" style="opacity:.75"><path d="M7 17 17 7"/><path d="M7 7h10v10"/></svg>
  </a>
</p>

<label>Tu correo de Tributando <span class="sub">(opcional: sin cuenta solo se guardan los XML en tu computador)</span></label><input id="email" value="{{email}}">
<label>Tu clave</label>
<div style="position:relative">
  <input id="clave" type="password" style="padding-right:42px">
  <span onclick="var c=document.getElementById('clave');c.type=c.type==='password'?'text':'password';this.style.opacity=c.type==='text'?'1':'.55'"
        style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;opacity:.55">
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#e6c483" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>
  </span>
</div>
<label style="display:flex;align-items:center;gap:8px">Enlace/token del correo DIAN del cliente
  <span id="tluz" style="display:none;align-items:center;gap:6px;font-size:.74rem;color:#37d38f">
    <i style="width:9px;height:9px;border-radius:50%;background:#37d38f;display:inline-block;animation:tluz 1.6s ease-in-out infinite"></i>
    token activo
  </span>
</label>
<input id="token" placeholder="https://catalogo-vpfe.dian.gov.co/User/AuthToken?...">
{% if claude %}<div style="display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap">
  <button type="button" id="btnClaude" onclick="prepararClaude()" style="flex:0 0 auto;width:auto;margin:0;padding:8px 14px;background:transparent;color:#9fd6b0;border:1px solid rgba(55,211,143,.5);font-size:.85rem">Dejar listo para Claude</button>
  <span id="claudeEstado" class="sub" style="color:#9fd6b0"></span>
</div>{% endif %}
<div class="fila">
  <div><label>Desde</label><input id="fi" type="date" value="{{fi}}"></div>
  <div><label>Hasta</label><input id="ff" type="date" value="{{ff}}"></div>
  <div><label>NIT/cédula del cliente <span class="sub">(p/ ZIP protegidos)</span></label>
       <input id="nit" placeholder="opcional"></div>
</div>
<div style="margin-top:12px">
  <label class="chk" style="cursor:pointer"><input type="checkbox" id="modoCufes" onchange="toggleCufes()" style="accent-color:#e6c483;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#e6c483" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Pegar CUFEs específicos (en vez del rango de fechas)</label>
  <textarea id="cufesManual" oninput="contarCufes()" placeholder="Pega los CUFEs, uno por línea (o separados por coma/espacio). Se bajan EXACTAMENTE esos." style="display:none;width:100%;box-sizing:border-box;margin-top:8px;min-height:96px;background:#1b2130;border:1px solid rgba(230,196,131,.35);border-radius:10px;color:#e8edf6;padding:10px 12px;font-family:ui-monospace,Menlo,monospace;font-size:.82rem"></textarea>
  <div id="cufesCount" class="sub" style="display:none;margin-top:5px;color:#9fd6b0"></div>
</div>
<div id="filtrosTipo" style="margin-top:12px;display:flex;flex-wrap:wrap;gap:12px">
  <label class="chk"><input type="checkbox" id="trec" checked style="accent-color:#37d38f;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9fd6b0" stroke-width="2" stroke-linecap="round"><path d="M12 19V5"/><path d="m5 12 7 7 7-7"/></svg>Recibidos (compras)</label>
  <label class="chk"><input type="checkbox" id="tenv" checked style="accent-color:#37d38f;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#e6c483" stroke-width="2" stroke-linecap="round"><path d="M12 5v14"/><path d="m19 12-7-7-7 7"/></svg>Enviados (ventas)</label>
  <label class="chk"><input type="checkbox" id="tnom" style="accent-color:#37d38f;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#e6c483" stroke-width="2" stroke-linecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></svg>Nómina electrónica</label>
  <label class="chk"><input type="checkbox" id="tsop" style="accent-color:#37d38f;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9fd6b0" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>Documento soporte</label>
  <label class="chk"><input type="checkbox" id="tpos" style="accent-color:#37d38f;width:16px;height:16px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9fd6b0" stroke-width="2" stroke-linecap="round"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8"/><path d="M8 11h8"/><path d="M8 15h5"/></svg>POS / equivalentes</label>
</div>
<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:14px">
  <button id="btnBuscar" onclick="buscar()" style="flex:0 0 auto;background:transparent;color:#e6c483;border:1px solid rgba(230,196,131,.55)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#e6c483" stroke-width="2.2" stroke-linecap="round" style="vertical-align:-3px;margin-right:7px"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>1 · Buscar en la DIAN</button>
  <span id="hallados" class="sub" style="color:#9fd6b0"></span>
</div>
<button id="btn" onclick="ir()"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1e2432" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-3px;margin-right:7px"><path d="M13 2 4.09 12.11a1 1 0 0 0 .76 1.64H11l-1 8 8.91-10.11a1 1 0 0 0-.76-1.64H13z"/></svg>2 · Descargar y enviar a la nube</button>
<div id="anillo" style="display:none;text-align:center;margin:22px 0 4px">
  <svg width="158" height="158" viewBox="0 0 130 130" style="filter:drop-shadow(0 6px 20px rgba(205,167,102,.30))">
    <defs><linearGradient id="oro" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#f2d99f"/><stop offset="1" stop-color="#c69a54"/></linearGradient></defs>
    <circle cx="65" cy="65" r="54" fill="none" stroke="#2a3145" stroke-width="12"/>
    <circle id="anArco" cx="65" cy="65" r="54" fill="none" stroke="url(#oro)" stroke-width="12"
            stroke-linecap="round" stroke-dasharray="339.29" stroke-dashoffset="339.29"
            transform="rotate(-90 65 65)"
            style="transition:stroke-dashoffset .55s cubic-bezier(.3,.9,.4,1),stroke .4s"/>
    <text id="anPct" x="65" y="65" text-anchor="middle" dominant-baseline="central"
          font-size="31" font-weight="800" fill="#f2d99f"
          font-family="ui-sans-serif,system-ui,-apple-system">0%</text>
    <text id="anSub" x="65" y="91" text-anchor="middle" font-size="10.5" fill="#8a93a6"
          letter-spacing=".05em">documentos</text>
  </svg>
</div>
<div id="crono" style="display:none;margin-top:14px;text-align:center">
  <span style="display:inline-flex;gap:14px;align-items:baseline;background:#1b2130;border:1px solid rgba(230,196,131,.35);border-radius:24px;padding:8px 22px">
    <span style="font-family:ui-monospace,Menlo,monospace;font-size:1.25rem;color:#e6c483;letter-spacing:.06em" id="cronoT">00:00</span>
    <span class="sub" id="cronoEta"></span>
  </span>
</div>
<div id="estado"></div>

<script>
const $=s=>document.querySelector(s);
(async function(){          // aviso de versión nueva al abrir
  try{
    const v=await (await fetch("/version")).json();
    if(v && v.hay_nueva){
      const a=document.getElementById("avisoLink"); if(a) a.href=v.zip;
      const c=document.getElementById("avisoVersion"); if(c) c.style.display="block";
    }
  }catch(e){}
})();
function _parseCufes(){
  return ($("#cufesManual").value||"").split(/[\s,;]+/).map(x=>x.trim()).filter(x=>x.length>=20);
}
function toggleCufes(){
  const on=$("#modoCufes").checked;
  $("#cufesManual").style.display=on?"block":"none";
  $("#cufesCount").style.display=on?"block":"none";
  $("#filtrosTipo").style.opacity=on?".35":"1";
  $("#filtrosTipo").style.pointerEvents=on?"none":"auto";
  const f=$("#fi").closest(".fila"); if(f){f.style.opacity=on?".35":"1";}
  // Con CUFEs pegados NO se busca por fechas: se va directo al paso 2 (antes el
  // «1 · Buscar» seguía activo, buscaba el rango e ignoraba la lista pegada).
  $("#btnBuscar").style.display=on?"none":"";
  $("#btn").disabled=false;
  if(on){$("#cufesManual").focus();contarCufes();}
}
function contarCufes(){
  const n=_parseCufes().length;
  $("#cufesCount").textContent=n?(n+" CUFE listos — dale «2 · Descargar y enviar a la nube»"):"Pega los CUFEs aquí…";
}
async function ir(){
  const modo=$("#modoCufes").checked;
  const cufes=modo?_parseCufes():[];
  const tipos=[]; if($("#trec").checked)tipos.push("recibidos");
  if($("#tenv").checked)tipos.push("enviados");
  if($("#tnom").checked)tipos.push("nomina");
  if($("#tsop").checked)tipos.push("soporte");
  if($("#tpos").checked)tipos.push("pos");
  const b={email:$("#email").value.trim(),clave:$("#clave").value,
           token:$("#token").value.trim(),fi:$("#fi").value,ff:$("#ff").value,
           nit:$("#nit").value.trim(),tipos:tipos,cufes:cufes,usar_listado:hallados>0};
  if(!b.token){alert("Falta el enlace/token de la DIAN.");return}
  if(!!b.email!==!!b.clave){alert("Para subir a la nube pon correo Y clave de Tributando; para solo guardar los XML en tu computador deja los dos vacíos.");return}
  if(modo){ if(!cufes.length){alert("Pega al menos un CUFE.");return} }
  else if(!tipos.length){alert("Marca al menos un tipo: recibidos, enviados, nómina, documento soporte o POS.");return}
  $("#btn").disabled=true;
  await fetch("/iniciar",{method:"POST",headers:{"Content-Type":"application/json"},
                          body:JSON.stringify(b)});
  sondear();
}
let hallados=0;      // documentos encontrados en la última búsqueda
async function prepararClaude(){
  const b={email:$("#email").value.trim(),clave:$("#clave").value,token:$("#token").value.trim()};
  if(!b.email||!b.clave||!b.token){alert("Falta correo, clave o enlace de la DIAN.");return}
  const r=await fetch("/preparar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});
  const j=await r.json();
  $("#claudeEstado").textContent=j.ok?("Listo para Claude ✓"+(j.nit?" · NIT "+j.nit:"")+" (solo en memoria; se borra al cerrar)"):(j.error||"No se pudo");
}
async function buscar(){
  if($("#modoCufes").checked){alert("Con CUFEs pegados no hay que buscar: dale «2 · Descargar y enviar a la nube».");return}
  const tipos=[]; if($("#trec").checked)tipos.push("recibidos");
  if($("#tenv").checked)tipos.push("enviados");
  if($("#tnom").checked)tipos.push("nomina");
  if($("#tsop").checked)tipos.push("soporte");
  if($("#tpos").checked)tipos.push("pos");
  const b={token:$("#token").value.trim(),fi:$("#fi").value,ff:$("#ff").value,tipos:tipos};
  if(!b.token){alert("Falta el token de la DIAN.");return}
  if(!tipos.length){alert("Marca al menos un tipo: recibidos, enviados, nómina, documento soporte o POS.");return}
  hallados=0; $("#hallados").textContent="";
  $("#btnBuscar").disabled=true; $("#btn").disabled=true;
  await fetch("/listar",{method:"POST",headers:{"Content-Type":"application/json"},
                         body:JSON.stringify(b)});
  sondear();
}
function abrirCarpeta(){ fetch("/abrir-carpeta",{method:"POST"}); }
let cronoTimer=null;
function fmt(seg){seg=Math.max(0,Math.round(seg));const m=Math.floor(seg/60),s2=seg%60;
  return (m<10?"0":"")+m+":"+(s2<10?"0":"")+s2;}
const AN_CIRC=339.29;
function anillo(p,sub,color){
  const a=document.getElementById("anillo"); if(!a)return; a.style.display="block";
  p=Math.max(0,Math.min(1,p||0));
  const arco=document.getElementById("anArco");
  arco.style.strokeDashoffset=AN_CIRC*(1-p);
  arco.style.stroke=color||"url(#oro)";
  const pct=document.getElementById("anPct");
  pct.textContent=Math.round(p*100)+"%"; pct.style.fill=color||"#f2d99f";
  if(sub!==undefined) document.getElementById("anSub").textContent=sub;
}
async function sondear(){
  const e=await (await fetch("/estado")).json();
  if(e.inicio&&!cronoTimer){
    document.getElementById("crono").style.display="block";
    cronoTimer=setInterval(()=>{
      const el=(Date.now()/1000)-e.inicio;
      document.getElementById("cronoT").textContent=fmt(el);
    },1000);
  }
  if(e.fase==="descargando"&&e.hechos>3){
    const el=(Date.now()/1000)-e.inicio;
    const eta=el/e.hechos*(e.total-e.hechos);
    document.getElementById("cronoEta").textContent="restante ~"+fmt(eta);
  }
  if(e.fase==="listado"){
    hallados=e.total||0;
    $("#hallados").textContent=hallados+" documento(s) encontrados — dale al paso 2";
    $("#btnBuscar").disabled=false; $("#btn").disabled=false;
    clearInterval(cronoTimer);cronoTimer=null;
  }
  if(e.fase==="listo"||e.fase==="error"){
    $("#btnBuscar").disabled=false;
    clearInterval(cronoTimer);cronoTimer=null;
    document.getElementById("cronoEta").textContent="";
  }
  // anillo de progreso dorado
  if(e.fase==="descargando"&&e.total){ anillo(e.hechos/e.total, e.hechos+"/"+e.total+" documentos"); }
  else if(e.fase==="listo"){ anillo(1,"¡listo!","#37d38f"); }
  else if(e.fase==="error"){ anillo(1,"con error","#e0666a"); }
  else if(e.fase==="listado"){ anillo(.5, e.total+" encontrados"); }
  else if(e.fase&&e.fase!=="quieto"){ anillo(.06, (e.detalle||"preparando…").slice(0,16)); }
  const box=$("#estado"); box.style.display="block";
  let txt="· "+e.detalle;
  if(e.fase==="descargando"&&e.total)
    txt+=`\\n${e.hechos}/${e.total} documentos`;
  if(e.fase==="listo"){
    const r=e.resumen||{};
    txt="✔ "+e.detalle+(r.solo_local?`\\nXML guardados: ${r.guardados||0}`:`\\nNuevas: ${r.nuevas||0} · Ya estaban: ${r.duplicadas||0}`
        +` · Contabilizadas: ${r.causadas||0}`)
        +(r.carpeta?`\\n📁 Copia de los XML en: ${r.carpeta}`:"")
        +(r.empresas_creadas?`\\n🏢 ${r.empresas_creadas} empresa(s) nueva(s) creada(s) sola(s)`:"")
        +(r.sin_empresa?`\\n⚠ ${r.sin_empresa} de otro NIT no registrado (no se contabilizaron)`:"");
    const det=Object.entries(r.por_empresa||{}).map(([k,v])=>`  ${k}: ${v}`).join("\\n");
    if(det) txt+="\\n"+det;
    const sd=Object.entries(r.sin_empresa_det||{});
    if(sd.length) txt+="\\n  NIT sin empresa: "+sd.map(([k,v])=>`${k}${v?" ("+v+")":""}`).join(" · ");
    if((e.errores||[]).length){
      txt+=`\\n△ ${e.errores.length} con error:`;
      e.errores.slice(0,15).forEach(er=>{txt+=`\\n   · ${er}`;});
      if(e.errores.length>15) txt+=`\\n   … y ${e.errores.length-15} más`;
    }
    $("#btn").disabled=false;
  }
  if(e.fase==="error"){ txt="✕ "+e.detalle; $("#btn").disabled=false; }
  box.innerHTML=txt.replace(/\\n/g,"<br>")
    +(e.fase==="listo"&&(e.resumen||{}).carpeta?'<br><button type="button" onclick="abrirCarpeta()" style="width:auto;margin-top:10px;padding:8px 16px">Abrir la carpeta de los XML</button>':"");
  if(e.fase!=="listo"&&e.fase!=="error") setTimeout(sondear,1500);
}
setInterval(async()=>{
  try{
    const e=await (await fetch("/estado")).json();
    const on = e.dian==="activo";
    document.getElementById("tluz").style.display = on?"inline-flex":"none";
    // Glow VERDE luminoso solo mientras activa el token o descarga; se apaga al terminar.
    const trabajando = (e.fase==="activando"||e.fase==="listando"||e.fase==="descargando");
    document.getElementById("btn").classList.toggle("btn-activo", trabajando);
  }catch(err){}
},3000);
</script>
<div class="sub" style="text-align:center;margin-top:20px;opacity:.7">Descargador Tributando · v{{version}}</div>
</body></html>"""


@app.route("/")
def portada():
    cfg = _cfg_leer()
    hoy = date.today()
    fi = (hoy.replace(day=1) - timedelta(days=1)).replace(day=1)
    return render_template_string(
        PAGINA, email=cfg.get("email", ""), fi=str(fi), ff=str(hoy),
        version=VERSION, claude=(sys.platform == "darwin"))


# Lo último que se buscó en la DIAN. Se guarda AQUÍ y no se manda al
# navegador: son cientos de CUFE y el front no los necesita para nada.
ULTIMO_LISTADO = {"fi": "", "ff": "", "tipos": [], "cufes": []}


def _trabajo_listar(datos: dict):
    """Paso 1: BUSCAR en la DIAN, sin bajar nada.

    Igual que el Lector: primero se ve cuántos documentos hay en el rango y
    después se descargan. Separarlo importa porque pedirle el listado al portal
    es lo que más tarda: si algo se cae en la descarga, la búsqueda no se
    repite, y si el rango no traía nada uno se entera en un minuto y no después
    de una corrida entera.
    """
    from dian_descargador import SESION
    try:
        _set(fase="activando", detalle="Abriendo sesión con el token de la DIAN…",
             errores=[], resumen=None, total=0, hechos=0,
             inicio=__import__("time").time())
        r = SESION.activar(datos["token"])
        if not r.get("ok"):
            _set(fase="error", detalle=r.get("error") or r.get("mensaje")
                 or "No se pudo activar el token.")
            return
        empresa = r.get("empresa", "")
        cufes, faltaron = [], []
        for tipo in datos["tipos"]:
            _set(fase="listando",
                 detalle=f"Buscando {tipo} ({datos['fi']} → {datos['ff']})…")
            rl = SESION.listar(datos["fi"], datos["ff"], tipo)
            if not rl.get("ok"):
                # Un tipo que falle no tumba la búsqueda: se sigue con los otros.
                faltaron.append(f"{tipo}: {rl.get('error') or 'sin respuesta'}")
                continue
            cufes += [c for c in rl.get("cufes", []) if c not in cufes]
        ULTIMO_LISTADO.update({"fi": datos["fi"], "ff": datos["ff"],
                               "tipos": list(datos["tipos"]), "cufes": cufes})
        if not cufes:
            _set(fase="error" if faltaron else "listo", total=0,
                 detalle=("No se pudo buscar — " + " · ".join(faltaron)) if faltaron
                         else "No hay documentos en ese rango.",
                 resumen={"nuevas": 0})
            return
        _set(fase="listado", total=len(cufes), hechos=0,
             detalle=f"{empresa}: se encontraron {len(cufes)} documento(s) "
                     f"entre {datos['fi']} y {datos['ff']}. "
                     "Dale «Descargar y enviar» para bajarlos."
                     + (" · NO se pudo buscar " + " · ".join(faltaron) if faltaron else ""))
    except Exception as ex:                                    # noqa: BLE001
        _set(fase="error", detalle=f"Falló la búsqueda: {ex}")


@app.route("/abrir-carpeta", methods=["POST"])
def abrir_carpeta():
    ruta = ((ESTADO.get("resumen") or {}).get("carpeta") or "")
    if not ruta or not os.path.isdir(ruta):
        return jsonify({"ok": False, "error": "No hay carpeta para abrir."}), 404
    try:
        if sys.platform.startswith("win"):
            os.startfile(ruta)                                   # noqa: S606
        else:
            import subprocess
            subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", ruta])
        return jsonify({"ok": True})
    except Exception as ex:                                      # noqa: BLE001
        return jsonify({"ok": False, "error": str(ex)}), 500


@app.route("/listar", methods=["POST"])
def listar_solo():
    if ESTADO["fase"] in ("activando", "listando", "descargando", "subiendo"):
        return jsonify({"ok": False, "error": "Ya hay algo en curso."}), 409
    b = request.json or {}
    datos = {"token": (b.get("token") or "").strip(),
             "fi": b.get("fi") or "", "ff": b.get("ff") or "",
             "tipos": b.get("tipos") or ["recibidos"]}
    if not datos["token"]:
        return jsonify({"ok": False, "error": "Falta el token de la DIAN."}), 400
    threading.Thread(target=_trabajo_listar, args=(datos,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/iniciar", methods=["POST"])
def iniciar():
    if ESTADO["fase"] in ("activando", "listando", "descargando", "subiendo"):
        return jsonify({"ok": False, "error": "Ya hay una descarga en curso."}), 409
    b = request.json or {}

    def _limpiar_cufes(v):
        """Acepta lista o texto pegado (líneas/comas/espacios); deja CUFEs válidos."""
        if isinstance(v, str):
            import re
            v = re.split(r"[\s,;]+", v)
        out = []
        for c in (v or []):
            c = (str(c) or "").strip()
            if len(c) >= 20 and c not in out:
                out.append(c)
        return out

    datos = {"email": (b.get("email") or "").strip().lower(),
             "clave": b.get("clave") or "",
             "token": (b.get("token") or "").strip(),
             "fi": b.get("fi") or "", "ff": b.get("ff") or "",
             "nit": (b.get("nit") or "").strip(),
             "tipos": b.get("tipos") or ["recibidos"],
             "cufes_manual": _limpiar_cufes(b.get("cufes")),
             "nube_": None,
             "nube": (b.get("nube") or NUBE_DEFAULT).strip()}
    datos.pop("nube_", None)
    # Si ya se buscó ese mismo rango, se bajan ESOS documentos y no se le
    # vuelve a pedir el listado al portal (que es lo que se demora).
    if (not datos["cufes_manual"] and b.get("usar_listado")
            and ULTIMO_LISTADO["cufes"]
            and ULTIMO_LISTADO["fi"] == datos["fi"]
            and ULTIMO_LISTADO["ff"] == datos["ff"]):
        datos["cufes_manual"] = list(ULTIMO_LISTADO["cufes"])
    _cfg_guardar({"email": datos["email"]})     # recordar solo el correo
    threading.Thread(target=_trabajo, args=(datos,), daemon=True).start()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Sesión para Claude (MCP local). El usuario pega el enlace de la DIAN y su
# correo/clave de Tributando EN ESTA VENTANA y le da «Dejar listo para Claude».
# Quedan SOLO en memoria de este proceso (nunca en disco, nunca se devuelven):
# Claude pide «buscar» o «descargar» por /mcp/* sin ver ni mandar credenciales.
# Al cerrar el programa se borran.
# ---------------------------------------------------------------------------
SESION_CLAUDE = {"email": "", "clave": "", "token": "", "nit": "", "empresa": ""}


def _nit_rk(u: str) -> str:
    import urllib.parse as _up
    try:
        return (_up.parse_qs(_up.urlparse(u).query).get("rk") or [""])[0].strip()
    except Exception:
        return ""


@app.route("/preparar", methods=["POST"])
def preparar_claude():
    b = request.json or {}
    email = (b.get("email") or "").strip().lower()
    clave = b.get("clave") or ""
    token = (b.get("token") or "").strip()
    if not (email and clave and token):
        return jsonify({"ok": False, "error": "Falta correo, clave o enlace de la DIAN."}), 400
    SESION_CLAUDE.update({"email": email, "clave": clave, "token": token,
                          "nit": _nit_rk(token), "empresa": ""})
    _cfg_guardar({"email": email})
    return jsonify({"ok": True, "nit": SESION_CLAUDE["nit"]})


@app.route("/preparar", methods=["DELETE"])
def olvidar_claude():
    SESION_CLAUDE.update({"email": "", "clave": "", "token": "", "nit": "", "empresa": ""})
    return jsonify({"ok": True})


def _datos_claude(b: dict) -> dict | None:
    if not (SESION_CLAUDE["token"] and SESION_CLAUDE["email"] and SESION_CLAUDE["clave"]):
        return None
    tipos = b.get("tipos") or ["recibidos"]
    if isinstance(tipos, str):
        tipos = [t.strip() for t in tipos.split(",") if t.strip()]
    return {"email": SESION_CLAUDE["email"], "clave": SESION_CLAUDE["clave"],
            "token": SESION_CLAUDE["token"], "fi": b.get("fi") or "",
            "ff": b.get("ff") or "", "nit": (b.get("nit") or SESION_CLAUDE["nit"] or "").strip(),
            "tipos": tipos, "cufes_manual": [], "nube": NUBE_DEFAULT}


@app.route("/mcp/listar", methods=["POST"])
def mcp_listar():
    if ESTADO["fase"] in ("activando", "listando", "descargando", "subiendo"):
        return jsonify({"ok": False, "error": "Ya hay algo en curso."}), 409
    datos = _datos_claude(request.json or {})
    if datos is None:
        return jsonify({"ok": False, "error": "El Recolector no está listo: pega el enlace "
                        "de la DIAN y tu correo/clave y dale «Dejar listo para Claude»."}), 400
    threading.Thread(target=_trabajo_listar, args=(datos,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/mcp/descargar", methods=["POST"])
def mcp_descargar():
    if ESTADO["fase"] in ("activando", "listando", "descargando", "subiendo"):
        return jsonify({"ok": False, "error": "Ya hay algo en curso."}), 409
    b = request.json or {}
    datos = _datos_claude(b)
    if datos is None:
        return jsonify({"ok": False, "error": "El Recolector no está listo: pega el enlace "
                        "de la DIAN y tu correo/clave y dale «Dejar listo para Claude»."}), 400
    if (ULTIMO_LISTADO["cufes"] and ULTIMO_LISTADO["fi"] == datos["fi"]
            and ULTIMO_LISTADO["ff"] == datos["ff"]):
        datos["cufes_manual"] = list(ULTIMO_LISTADO["cufes"])
    threading.Thread(target=_trabajo, args=(datos,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/version")
def version():
    """Compara la versión local contra el version.txt del repo de descargas."""
    remoto = ""
    try:
        with urllib.request.urlopen(REPO_RAW + "/version.txt", timeout=8) as r:
            remoto = r.read().decode("utf-8").strip()
    except Exception:
        remoto = ""

    def _t(v):
        try:
            return tuple(int(x) for x in str(v).strip().split("."))
        except Exception:
            return ()

    hay = bool(remoto) and _t(remoto) > _t(VERSION)
    return jsonify({"local": VERSION, "remoto": remoto, "hay_nueva": hay,
                    "zip": REPO_RAW + "/Descargador-Tributando.zip"})


@app.route("/estado")
def estado():
    import sys
    with _LOCK:
        d = dict(ESTADO)
    d["dian"] = "inactivo"
    d["claude_listo"] = bool(SESION_CLAUDE["token"] and SESION_CLAUDE["clave"])
    d["claude_nit"] = SESION_CLAUDE["nit"]
    d["ultimo_listado"] = {"fi": ULTIMO_LISTADO["fi"], "ff": ULTIMO_LISTADO["ff"],
                           "tipos": ULTIMO_LISTADO["tipos"],
                           "n": len(ULTIMO_LISTADO["cufes"])}
    mod = sys.modules.get("dian_descargador")
    if mod is not None:
        try:
            _ses = mod.SESION.estado()
            d["dian"] = _ses.get("estado", "inactivo")
            # Mientras abre la sesión, mostrar lo que va haciendo con el captcha
            # (recargando, «márcalo en la ventana»…), no solo «Abriendo sesión».
            if d.get("fase") == "activando" and _ses.get("estado") == "activando" \
                    and _ses.get("mensaje"):
                d["detalle"] = _ses["mensaje"]
        except Exception:
            pass
    return jsonify(d)


def _limpiar_chrome_huerfano():
    """Mata Chromes huérfanos de corridas anteriores que agarran el perfil de
    Playwright (si quedan vivos, el navegador nuevo choca y se cae al listar)."""
    import subprocess
    try:
        pids = subprocess.run(["pgrep", "-f", "perfil_chrome"],
                              capture_output=True, text=True).stdout.split()
        for pid in pids:
            subprocess.run(["kill", pid], capture_output=True)
        lock = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            ".perfil_chrome", "SingletonLock")
        if os.path.lexists(lock):
            os.remove(lock)
    except Exception:
        pass


if __name__ == "__main__":
    _limpiar_chrome_huerfano()
    print("Descargador Tributando → Nube · http://127.0.0.1:5077")
    app.run(host="127.0.0.1", port=5077, debug=False)
