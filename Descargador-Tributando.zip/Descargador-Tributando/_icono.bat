@echo off
REM Crea el acceso directo "Descargador Tributando" (con el LOGO) en el
REM Escritorio y el menu Inicio, y ADEMAS intenta anclarlo a la barra de tareas.
REM El destino es wscript.exe (ejecutable real) para que sea anclable.
cd /d "%~dp0"
set "PS=%TEMP%\_trib_icono.ps1"
>"%PS%" echo $w=New-Object -ComObject WScript.Shell
>>"%PS%" echo $q=[char]34
>>"%PS%" echo $vbs='%~dp0Descargador Tributando.vbs'
>>"%PS%" echo $ico='%~dp0static\tributando.ico'
>>"%PS%" echo $ws=$env:SystemRoot + '\System32\wscript.exe'
>>"%PS%" echo $d=[Environment]::GetFolderPath('Desktop') + '\Descargador Tributando.lnk'
>>"%PS%" echo $s=$w.CreateShortcut($d); $s.TargetPath=$ws; $s.Arguments=$q + $vbs + $q; $s.IconLocation=$ico; $s.WorkingDirectory='%~dp0'; $s.Description='Descargador Tributando'; $s.Save()
>>"%PS%" echo $p=[Environment]::GetFolderPath('Programs') + '\Descargador Tributando.lnk'
>>"%PS%" echo $s2=$w.CreateShortcut($p); $s2.TargetPath=$ws; $s2.Arguments=$q + $vbs + $q; $s2.IconLocation=$ico; $s2.WorkingDirectory='%~dp0'; $s2.Save()
>>"%PS%" echo try{ $sh=New-Object -ComObject Shell.Application; $dir=$sh.Namespace([Environment]::GetFolderPath('Desktop')); $it=$dir.ParseName('Descargador Tributando.lnk'); foreach($v in $it.Verbs()){ if($v.Name -match 'barra de tareas^|taskbar'){ $v.DoIt() } } }catch{}
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS%" >nul 2>&1
del "%PS%" >nul 2>&1
